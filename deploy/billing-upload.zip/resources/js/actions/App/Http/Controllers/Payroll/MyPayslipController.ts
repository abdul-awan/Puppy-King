import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/my-payslips',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::index
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:25
 * @route '/{current_team}/my-payslips'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
export const pdf = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/my-payslips/{payslip}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
pdf.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
pdf.get = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
pdf.head = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\MyPayslipController::pdf
 * @see app/Http/Controllers/Payroll/MyPayslipController.php:39
 * @route '/{current_team}/my-payslips/{payslip}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
const MyPayslipController = { index, pdf }

export default MyPayslipController