import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::index
 * @see app/Http/Controllers/Reports/ReportController.php:51
 * @route '/{current_team}/reports'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
export const revenue = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: revenue.url(args, options),
    method: 'get',
})

revenue.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/revenue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
revenue.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return revenue.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
revenue.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: revenue.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
revenue.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: revenue.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
    const revenueForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: revenue.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
        revenueForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: revenue.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::revenue
 * @see app/Http/Controllers/Reports/ReportController.php:64
 * @route '/{current_team}/reports/revenue'
 */
        revenueForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: revenue.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    revenue.form = revenueForm
/**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
export const receivables = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receivables.url(args, options),
    method: 'get',
})

receivables.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/receivables',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
receivables.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return receivables.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
receivables.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receivables.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
receivables.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receivables.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
    const receivablesForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: receivables.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
        receivablesForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receivables.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::receivables
 * @see app/Http/Controllers/Reports/ReportController.php:81
 * @route '/{current_team}/reports/receivables'
 */
        receivablesForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: receivables.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    receivables.form = receivablesForm
/**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
export const salesTax = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salesTax.url(args, options),
    method: 'get',
})

salesTax.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/sales-tax',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
salesTax.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return salesTax.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
salesTax.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salesTax.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
salesTax.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: salesTax.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
    const salesTaxForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: salesTax.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
        salesTaxForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salesTax.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::salesTax
 * @see app/Http/Controllers/Reports/ReportController.php:96
 * @route '/{current_team}/reports/sales-tax'
 */
        salesTaxForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salesTax.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    salesTax.form = salesTaxForm
/**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
export const pipeline = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipeline.url(args, options),
    method: 'get',
})

pipeline.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/pipeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
pipeline.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return pipeline.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
pipeline.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipeline.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
pipeline.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pipeline.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
    const pipelineForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pipeline.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
        pipelineForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipeline.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::pipeline
 * @see app/Http/Controllers/Reports/ReportController.php:110
 * @route '/{current_team}/reports/pipeline'
 */
        pipelineForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipeline.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pipeline.form = pipelineForm
/**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
export const time = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: time.url(args, options),
    method: 'get',
})

time.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/time',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
time.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return time.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
time.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: time.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
time.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: time.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
    const timeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: time.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
        timeForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: time.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::time
 * @see app/Http/Controllers/Reports/ReportController.php:125
 * @route '/{current_team}/reports/time'
 */
        timeForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: time.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    time.form = timeForm
/**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
export const expenses = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(args, options),
    method: 'get',
})

expenses.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
expenses.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return expenses.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
expenses.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
expenses.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expenses.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
    const expensesForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: expenses.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
        expensesForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: expenses.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::expenses
 * @see app/Http/Controllers/Reports/ReportController.php:143
 * @route '/{current_team}/reports/expenses'
 */
        expensesForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: expenses.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    expenses.form = expensesForm
/**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
export const dailyExpenses = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyExpenses.url(args, options),
    method: 'get',
})

dailyExpenses.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/daily-expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
dailyExpenses.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return dailyExpenses.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
dailyExpenses.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyExpenses.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
dailyExpenses.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyExpenses.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
    const dailyExpensesForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dailyExpenses.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
        dailyExpensesForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dailyExpenses.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::dailyExpenses
 * @see app/Http/Controllers/Reports/ReportController.php:157
 * @route '/{current_team}/reports/daily-expenses'
 */
        dailyExpensesForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dailyExpenses.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dailyExpenses.form = dailyExpensesForm
/**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
export const payroll = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(args, options),
    method: 'get',
})

payroll.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
payroll.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return payroll.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
payroll.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
payroll.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payroll.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
    const payrollForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: payroll.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
        payrollForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: payroll.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::payroll
 * @see app/Http/Controllers/Reports/ReportController.php:171
 * @route '/{current_team}/reports/payroll'
 */
        payrollForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: payroll.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    payroll.form = payrollForm
/**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
export const exportMethod = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/reports/{report}/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
exportMethod.url = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    report: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                report: args.report,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{report}', parsedArgs.report.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
exportMethod.get = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
exportMethod.head = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
    const exportMethodForm = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
        exportMethodForm.get = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ReportController::exportMethod
 * @see app/Http/Controllers/Reports/ReportController.php:185
 * @route '/{current_team}/reports/{report}/export'
 */
        exportMethodForm.head = (args: { current_team: string | number, report: string | number } | [current_team: string | number, report: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const ReportController = { index, revenue, receivables, salesTax, pipeline, time, expenses, dailyExpenses, payroll, exportMethod, export: exportMethod }

export default ReportController