import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NotificationController::readAll
 * @see app/Http/Controllers/NotificationController.php:38
 * @route '/{current_team}/notifications/read-all'
 */
export const readAll = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(args, options),
    method: 'post',
})

readAll.definition = {
    methods: ["post"],
    url: '/{current_team}/notifications/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::readAll
 * @see app/Http/Controllers/NotificationController.php:38
 * @route '/{current_team}/notifications/read-all'
 */
readAll.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return readAll.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::readAll
 * @see app/Http/Controllers/NotificationController.php:38
 * @route '/{current_team}/notifications/read-all'
 */
readAll.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::readAll
 * @see app/Http/Controllers/NotificationController.php:38
 * @route '/{current_team}/notifications/read-all'
 */
    const readAllForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: readAll.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::readAll
 * @see app/Http/Controllers/NotificationController.php:38
 * @route '/{current_team}/notifications/read-all'
 */
        readAllForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: readAll.url(args, options),
            method: 'post',
        })
    
    readAll.form = readAllForm
/**
* @see \App\Http\Controllers\NotificationController::read
 * @see app/Http/Controllers/NotificationController.php:18
 * @route '/{current_team}/notifications/{notification}/read'
 */
export const read = (args: { current_team: string | number, notification: string | number } | [current_team: string | number, notification: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

read.definition = {
    methods: ["post"],
    url: '/{current_team}/notifications/{notification}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::read
 * @see app/Http/Controllers/NotificationController.php:18
 * @route '/{current_team}/notifications/{notification}/read'
 */
read.url = (args: { current_team: string | number, notification: string | number } | [current_team: string | number, notification: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    notification: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                notification: args.notification,
                }

    return read.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::read
 * @see app/Http/Controllers/NotificationController.php:18
 * @route '/{current_team}/notifications/{notification}/read'
 */
read.post = (args: { current_team: string | number, notification: string | number } | [current_team: string | number, notification: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::read
 * @see app/Http/Controllers/NotificationController.php:18
 * @route '/{current_team}/notifications/{notification}/read'
 */
    const readForm = (args: { current_team: string | number, notification: string | number } | [current_team: string | number, notification: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::read
 * @see app/Http/Controllers/NotificationController.php:18
 * @route '/{current_team}/notifications/{notification}/read'
 */
        readForm.post = (args: { current_team: string | number, notification: string | number } | [current_team: string | number, notification: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, options),
            method: 'post',
        })
    
    read.form = readForm
const NotificationController = { readAll, read }

export default NotificationController