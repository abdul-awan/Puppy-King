import InvoiceController from './InvoiceController'
import InvoicePaymentController from './InvoicePaymentController'
import CreditNoteController from './CreditNoteController'
import RecurringInvoiceController from './RecurringInvoiceController'
const Invoicing = {
    InvoiceController: Object.assign(InvoiceController, InvoiceController),
InvoicePaymentController: Object.assign(InvoicePaymentController, InvoicePaymentController),
CreditNoteController: Object.assign(CreditNoteController, CreditNoteController),
RecurringInvoiceController: Object.assign(RecurringInvoiceController, RecurringInvoiceController),
}

export default Invoicing