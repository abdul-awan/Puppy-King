import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/lost-reasons',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::index
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:38
 * @route '/{current_team}/settings/lost-reasons'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::store
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:50
 * @route '/{current_team}/settings/lost-reasons'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/lost-reasons',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::store
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:50
 * @route '/{current_team}/settings/lost-reasons'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::store
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:50
 * @route '/{current_team}/settings/lost-reasons'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::store
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:50
 * @route '/{current_team}/settings/lost-reasons'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::store
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:50
 * @route '/{current_team}/settings/lost-reasons'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
export const update = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/lost-reasons/{lost_reason}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
update.url = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    lost_reason: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                lost_reason: args.lost_reason,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{lost_reason}', parsedArgs.lost_reason.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
update.put = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
update.patch = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
    const updateForm = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
        updateForm.put = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::update
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:63
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
        updateForm.patch = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::destroy
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:76
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
export const destroy = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/lost-reasons/{lost_reason}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::destroy
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:76
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
destroy.url = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    lost_reason: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                lost_reason: args.lost_reason,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{lost_reason}', parsedArgs.lost_reason.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::destroy
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:76
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
destroy.delete = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::destroy
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:76
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
    const destroyForm = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\LostReasonController::destroy
 * @see app/Http/Controllers/CompanySettings/LostReasonController.php:76
 * @route '/{current_team}/settings/lost-reasons/{lost_reason}'
 */
        destroyForm.delete = (args: { current_team: string | number, lost_reason: string | number } | [current_team: string | number, lost_reason: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const LostReasonController = { index, store, update, destroy }

export default LostReasonController