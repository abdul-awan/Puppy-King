import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
export const pdf = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/quotations/{quotation}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
pdf.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
pdf.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
pdf.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::pdf
 * @see app/Http/Controllers/Documents/QuotationController.php:207
 * @route '/{current_team}/quotations/{quotation}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::send
 * @see app/Http/Controllers/Documents/QuotationController.php:220
 * @route '/{current_team}/quotations/{quotation}/send'
 */
export const send = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::send
 * @see app/Http/Controllers/Documents/QuotationController.php:220
 * @route '/{current_team}/quotations/{quotation}/send'
 */
send.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return send.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::send
 * @see app/Http/Controllers/Documents/QuotationController.php:220
 * @route '/{current_team}/quotations/{quotation}/send'
 */
send.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::send
 * @see app/Http/Controllers/Documents/QuotationController.php:220
 * @route '/{current_team}/quotations/{quotation}/send'
 */
    const sendForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::send
 * @see app/Http/Controllers/Documents/QuotationController.php:220
 * @route '/{current_team}/quotations/{quotation}/send'
 */
        sendForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(args, options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::markSent
 * @see app/Http/Controllers/Documents/QuotationController.php:243
 * @route '/{current_team}/quotations/{quotation}/mark-sent'
 */
export const markSent = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSent.url(args, options),
    method: 'post',
})

markSent.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/mark-sent',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::markSent
 * @see app/Http/Controllers/Documents/QuotationController.php:243
 * @route '/{current_team}/quotations/{quotation}/mark-sent'
 */
markSent.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return markSent.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::markSent
 * @see app/Http/Controllers/Documents/QuotationController.php:243
 * @route '/{current_team}/quotations/{quotation}/mark-sent'
 */
markSent.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSent.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::markSent
 * @see app/Http/Controllers/Documents/QuotationController.php:243
 * @route '/{current_team}/quotations/{quotation}/mark-sent'
 */
    const markSentForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markSent.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::markSent
 * @see app/Http/Controllers/Documents/QuotationController.php:243
 * @route '/{current_team}/quotations/{quotation}/mark-sent'
 */
        markSentForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markSent.url(args, options),
            method: 'post',
        })
    
    markSent.form = markSentForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::accept
 * @see app/Http/Controllers/Documents/QuotationController.php:257
 * @route '/{current_team}/quotations/{quotation}/accept'
 */
export const accept = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

accept.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/accept',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::accept
 * @see app/Http/Controllers/Documents/QuotationController.php:257
 * @route '/{current_team}/quotations/{quotation}/accept'
 */
accept.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return accept.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::accept
 * @see app/Http/Controllers/Documents/QuotationController.php:257
 * @route '/{current_team}/quotations/{quotation}/accept'
 */
accept.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::accept
 * @see app/Http/Controllers/Documents/QuotationController.php:257
 * @route '/{current_team}/quotations/{quotation}/accept'
 */
    const acceptForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::accept
 * @see app/Http/Controllers/Documents/QuotationController.php:257
 * @route '/{current_team}/quotations/{quotation}/accept'
 */
        acceptForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(args, options),
            method: 'post',
        })
    
    accept.form = acceptForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::decline
 * @see app/Http/Controllers/Documents/QuotationController.php:269
 * @route '/{current_team}/quotations/{quotation}/decline'
 */
export const decline = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decline.url(args, options),
    method: 'post',
})

decline.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/decline',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::decline
 * @see app/Http/Controllers/Documents/QuotationController.php:269
 * @route '/{current_team}/quotations/{quotation}/decline'
 */
decline.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return decline.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::decline
 * @see app/Http/Controllers/Documents/QuotationController.php:269
 * @route '/{current_team}/quotations/{quotation}/decline'
 */
decline.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decline.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::decline
 * @see app/Http/Controllers/Documents/QuotationController.php:269
 * @route '/{current_team}/quotations/{quotation}/decline'
 */
    const declineForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: decline.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::decline
 * @see app/Http/Controllers/Documents/QuotationController.php:269
 * @route '/{current_team}/quotations/{quotation}/decline'
 */
        declineForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: decline.url(args, options),
            method: 'post',
        })
    
    decline.form = declineForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::reopen
 * @see app/Http/Controllers/Documents/QuotationController.php:283
 * @route '/{current_team}/quotations/{quotation}/reopen'
 */
export const reopen = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

reopen.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/reopen',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::reopen
 * @see app/Http/Controllers/Documents/QuotationController.php:283
 * @route '/{current_team}/quotations/{quotation}/reopen'
 */
reopen.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return reopen.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::reopen
 * @see app/Http/Controllers/Documents/QuotationController.php:283
 * @route '/{current_team}/quotations/{quotation}/reopen'
 */
reopen.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::reopen
 * @see app/Http/Controllers/Documents/QuotationController.php:283
 * @route '/{current_team}/quotations/{quotation}/reopen'
 */
    const reopenForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reopen.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::reopen
 * @see app/Http/Controllers/Documents/QuotationController.php:283
 * @route '/{current_team}/quotations/{quotation}/reopen'
 */
        reopenForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reopen.url(args, options),
            method: 'post',
        })
    
    reopen.form = reopenForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::duplicate
 * @see app/Http/Controllers/Documents/QuotationController.php:303
 * @route '/{current_team}/quotations/{quotation}/duplicate'
 */
export const duplicate = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

duplicate.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/duplicate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::duplicate
 * @see app/Http/Controllers/Documents/QuotationController.php:303
 * @route '/{current_team}/quotations/{quotation}/duplicate'
 */
duplicate.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return duplicate.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::duplicate
 * @see app/Http/Controllers/Documents/QuotationController.php:303
 * @route '/{current_team}/quotations/{quotation}/duplicate'
 */
duplicate.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::duplicate
 * @see app/Http/Controllers/Documents/QuotationController.php:303
 * @route '/{current_team}/quotations/{quotation}/duplicate'
 */
    const duplicateForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: duplicate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::duplicate
 * @see app/Http/Controllers/Documents/QuotationController.php:303
 * @route '/{current_team}/quotations/{quotation}/duplicate'
 */
        duplicateForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: duplicate.url(args, options),
            method: 'post',
        })
    
    duplicate.form = duplicateForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::invoice
 * @see app/Http/Controllers/Documents/QuotationController.php:332
 * @route '/{current_team}/quotations/{quotation}/invoice'
 */
export const invoice = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoice.url(args, options),
    method: 'post',
})

invoice.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations/{quotation}/invoice',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::invoice
 * @see app/Http/Controllers/Documents/QuotationController.php:332
 * @route '/{current_team}/quotations/{quotation}/invoice'
 */
invoice.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return invoice.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::invoice
 * @see app/Http/Controllers/Documents/QuotationController.php:332
 * @route '/{current_team}/quotations/{quotation}/invoice'
 */
invoice.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::invoice
 * @see app/Http/Controllers/Documents/QuotationController.php:332
 * @route '/{current_team}/quotations/{quotation}/invoice'
 */
    const invoiceForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invoice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::invoice
 * @see app/Http/Controllers/Documents/QuotationController.php:332
 * @route '/{current_team}/quotations/{quotation}/invoice'
 */
        invoiceForm.post = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invoice.url(args, options),
            method: 'post',
        })
    
    invoice.form = invoiceForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/quotations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::index
 * @see app/Http/Controllers/Documents/QuotationController.php:43
 * @route '/{current_team}/quotations'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/quotations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::create
 * @see app/Http/Controllers/Documents/QuotationController.php:86
 * @route '/{current_team}/quotations/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::store
 * @see app/Http/Controllers/Documents/QuotationController.php:114
 * @route '/{current_team}/quotations'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/quotations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::store
 * @see app/Http/Controllers/Documents/QuotationController.php:114
 * @route '/{current_team}/quotations'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::store
 * @see app/Http/Controllers/Documents/QuotationController.php:114
 * @route '/{current_team}/quotations'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::store
 * @see app/Http/Controllers/Documents/QuotationController.php:114
 * @route '/{current_team}/quotations'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::store
 * @see app/Http/Controllers/Documents/QuotationController.php:114
 * @route '/{current_team}/quotations'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
export const show = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/quotations/{quotation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
show.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
show.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
show.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
    const showForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
        showForm.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::show
 * @see app/Http/Controllers/Documents/QuotationController.php:144
 * @route '/{current_team}/quotations/{quotation}'
 */
        showForm.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
export const edit = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/quotations/{quotation}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
edit.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
edit.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
edit.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
    const editForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
        editForm.get = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::edit
 * @see app/Http/Controllers/Documents/QuotationController.php:159
 * @route '/{current_team}/quotations/{quotation}/edit'
 */
        editForm.head = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
export const update = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/quotations/{quotation}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
update.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
update.put = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
update.patch = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
    const updateForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
        updateForm.put = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Documents\QuotationController::update
 * @see app/Http/Controllers/Documents/QuotationController.php:174
 * @route '/{current_team}/quotations/{quotation}'
 */
        updateForm.patch = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Documents\QuotationController::destroy
 * @see app/Http/Controllers/Documents/QuotationController.php:195
 * @route '/{current_team}/quotations/{quotation}'
 */
export const destroy = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/quotations/{quotation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Documents\QuotationController::destroy
 * @see app/Http/Controllers/Documents/QuotationController.php:195
 * @route '/{current_team}/quotations/{quotation}'
 */
destroy.url = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Documents\QuotationController::destroy
 * @see app/Http/Controllers/Documents/QuotationController.php:195
 * @route '/{current_team}/quotations/{quotation}'
 */
destroy.delete = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Documents\QuotationController::destroy
 * @see app/Http/Controllers/Documents/QuotationController.php:195
 * @route '/{current_team}/quotations/{quotation}'
 */
    const destroyForm = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Documents\QuotationController::destroy
 * @see app/Http/Controllers/Documents/QuotationController.php:195
 * @route '/{current_team}/quotations/{quotation}'
 */
        destroyForm.delete = (args: { current_team: string | number, quotation: number | { id: number } } | [current_team: string | number, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const QuotationController = { pdf, send, markSent, accept, decline, reopen, duplicate, invoice, index, create, store, show, edit, update, destroy }

export default QuotationController