import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::store
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:64
 * @route '/{current_team}/invoices/{invoice}/payments'
 */
export const store = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::store
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:64
 * @route '/{current_team}/invoices/{invoice}/payments'
 */
store.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::store
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:64
 * @route '/{current_team}/invoices/{invoice}/payments'
 */
store.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::store
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:64
 * @route '/{current_team}/invoices/{invoice}/payments'
 */
    const storeForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::store
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:64
 * @route '/{current_team}/invoices/{invoice}/payments'
 */
        storeForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::destroy
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:76
 * @route '/{current_team}/invoices/{invoice}/payments/{payment}'
 */
export const destroy = (args: { current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/invoices/{invoice}/payments/{payment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::destroy
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:76
 * @route '/{current_team}/invoices/{invoice}/payments/{payment}'
 */
destroy.url = (args: { current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                    payment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                                payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::destroy
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:76
 * @route '/{current_team}/invoices/{invoice}/payments/{payment}'
 */
destroy.delete = (args: { current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::destroy
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:76
 * @route '/{current_team}/invoices/{invoice}/payments/{payment}'
 */
    const destroyForm = (args: { current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::destroy
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:76
 * @route '/{current_team}/invoices/{invoice}/payments/{payment}'
 */
        destroyForm.delete = (args: { current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, invoice: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoicePaymentController::index
 * @see app/Http/Controllers/Invoicing/InvoicePaymentController.php:24
 * @route '/{current_team}/payments'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const InvoicePaymentController = { store, destroy, index }

export default InvoicePaymentController