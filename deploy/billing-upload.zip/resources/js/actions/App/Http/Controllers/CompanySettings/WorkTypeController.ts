import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/work-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::index
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:17
 * @route '/{current_team}/settings/work-types'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::store
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:30
 * @route '/{current_team}/settings/work-types'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/work-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::store
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:30
 * @route '/{current_team}/settings/work-types'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::store
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:30
 * @route '/{current_team}/settings/work-types'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::store
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:30
 * @route '/{current_team}/settings/work-types'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::store
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:30
 * @route '/{current_team}/settings/work-types'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
export const update = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/work-types/{work_type}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
update.url = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    work_type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                work_type: typeof args.work_type === 'object'
                ? args.work_type.id
                : args.work_type,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{work_type}', parsedArgs.work_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
update.put = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
update.patch = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
    const updateForm = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
        updateForm.put = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::update
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:44
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
        updateForm.patch = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::destroy
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:56
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
export const destroy = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/work-types/{work_type}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::destroy
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:56
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
destroy.url = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    work_type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                work_type: typeof args.work_type === 'object'
                ? args.work_type.id
                : args.work_type,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{work_type}', parsedArgs.work_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::destroy
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:56
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
destroy.delete = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::destroy
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:56
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
    const destroyForm = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\WorkTypeController::destroy
 * @see app/Http/Controllers/CompanySettings/WorkTypeController.php:56
 * @route '/{current_team}/settings/work-types/{work_type}'
 */
        destroyForm.delete = (args: { current_team: string | number, work_type: number | { id: number } } | [current_team: string | number, work_type: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const WorkTypeController = { index, store, update, destroy }

export default WorkTypeController