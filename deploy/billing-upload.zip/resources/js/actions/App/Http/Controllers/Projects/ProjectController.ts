import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Projects\ProjectController::status
 * @see app/Http/Controllers/Projects/ProjectController.php:203
 * @route '/{current_team}/projects/{project}/status'
 */
export const status = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/{current_team}/projects/{project}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::status
 * @see app/Http/Controllers/Projects/ProjectController.php:203
 * @route '/{current_team}/projects/{project}/status'
 */
status.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return status.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::status
 * @see app/Http/Controllers/Projects/ProjectController.php:203
 * @route '/{current_team}/projects/{project}/status'
 */
status.patch = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::status
 * @see app/Http/Controllers/Projects/ProjectController.php:203
 * @route '/{current_team}/projects/{project}/status'
 */
    const statusForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::status
 * @see app/Http/Controllers/Projects/ProjectController.php:203
 * @route '/{current_team}/projects/{project}/status'
 */
        statusForm.patch = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::invoice
 * @see app/Http/Controllers/Projects/ProjectController.php:232
 * @route '/{current_team}/projects/{project}/invoice'
 */
export const invoice = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoice.url(args, options),
    method: 'post',
})

invoice.definition = {
    methods: ["post"],
    url: '/{current_team}/projects/{project}/invoice',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::invoice
 * @see app/Http/Controllers/Projects/ProjectController.php:232
 * @route '/{current_team}/projects/{project}/invoice'
 */
invoice.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return invoice.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::invoice
 * @see app/Http/Controllers/Projects/ProjectController.php:232
 * @route '/{current_team}/projects/{project}/invoice'
 */
invoice.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoice.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::invoice
 * @see app/Http/Controllers/Projects/ProjectController.php:232
 * @route '/{current_team}/projects/{project}/invoice'
 */
    const invoiceForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invoice.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::invoice
 * @see app/Http/Controllers/Projects/ProjectController.php:232
 * @route '/{current_team}/projects/{project}/invoice'
 */
        invoiceForm.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invoice.url(args, options),
            method: 'post',
        })
    
    invoice.form = invoiceForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Projects\ProjectController::index
 * @see app/Http/Controllers/Projects/ProjectController.php:45
 * @route '/{current_team}/projects'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/projects/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Projects\ProjectController::create
 * @see app/Http/Controllers/Projects/ProjectController.php:86
 * @route '/{current_team}/projects/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::store
 * @see app/Http/Controllers/Projects/ProjectController.php:114
 * @route '/{current_team}/projects'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::store
 * @see app/Http/Controllers/Projects/ProjectController.php:114
 * @route '/{current_team}/projects'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::store
 * @see app/Http/Controllers/Projects/ProjectController.php:114
 * @route '/{current_team}/projects'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::store
 * @see app/Http/Controllers/Projects/ProjectController.php:114
 * @route '/{current_team}/projects'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::store
 * @see app/Http/Controllers/Projects/ProjectController.php:114
 * @route '/{current_team}/projects'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
export const show = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/projects/{project}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
show.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
show.get = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
show.head = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
    const showForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
        showForm.get = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Projects\ProjectController::show
 * @see app/Http/Controllers/Projects/ProjectController.php:136
 * @route '/{current_team}/projects/{project}'
 */
        showForm.head = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
export const edit = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/projects/{project}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
edit.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
edit.get = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
edit.head = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
    const editForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
        editForm.get = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Projects\ProjectController::edit
 * @see app/Http/Controllers/Projects/ProjectController.php:174
 * @route '/{current_team}/projects/{project}/edit'
 */
        editForm.head = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
export const update = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/projects/{project}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
update.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
update.put = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
update.patch = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
    const updateForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
        updateForm.put = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Projects\ProjectController::update
 * @see app/Http/Controllers/Projects/ProjectController.php:187
 * @route '/{current_team}/projects/{project}'
 */
        updateForm.patch = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Projects\ProjectController::destroy
 * @see app/Http/Controllers/Projects/ProjectController.php:217
 * @route '/{current_team}/projects/{project}'
 */
export const destroy = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/projects/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Projects\ProjectController::destroy
 * @see app/Http/Controllers/Projects/ProjectController.php:217
 * @route '/{current_team}/projects/{project}'
 */
destroy.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectController::destroy
 * @see app/Http/Controllers/Projects/ProjectController.php:217
 * @route '/{current_team}/projects/{project}'
 */
destroy.delete = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectController::destroy
 * @see app/Http/Controllers/Projects/ProjectController.php:217
 * @route '/{current_team}/projects/{project}'
 */
    const destroyForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectController::destroy
 * @see app/Http/Controllers/Projects/ProjectController.php:217
 * @route '/{current_team}/projects/{project}'
 */
        destroyForm.delete = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ProjectController = { status, invoice, index, create, store, show, edit, update, destroy }

export default ProjectController