import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Crm\CompanyContactController::store
 * @see app/Http/Controllers/Crm/CompanyContactController.php:17
 * @route '/{current_team}/companies/{company}/contacts'
 */
export const store = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/companies/{company}/contacts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::store
 * @see app/Http/Controllers/Crm/CompanyContactController.php:17
 * @route '/{current_team}/companies/{company}/contacts'
 */
store.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::store
 * @see app/Http/Controllers/Crm/CompanyContactController.php:17
 * @route '/{current_team}/companies/{company}/contacts'
 */
store.post = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyContactController::store
 * @see app/Http/Controllers/Crm/CompanyContactController.php:17
 * @route '/{current_team}/companies/{company}/contacts'
 */
    const storeForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyContactController::store
 * @see app/Http/Controllers/Crm/CompanyContactController.php:17
 * @route '/{current_team}/companies/{company}/contacts'
 */
        storeForm.post = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Crm\CompanyContactController::update
 * @see app/Http/Controllers/Crm/CompanyContactController.php:31
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
export const update = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/{current_team}/companies/{company}/contacts/{contact}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::update
 * @see app/Http/Controllers/Crm/CompanyContactController.php:31
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
update.url = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                    contact: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::update
 * @see app/Http/Controllers/Crm/CompanyContactController.php:31
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
update.patch = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyContactController::update
 * @see app/Http/Controllers/Crm/CompanyContactController.php:31
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
    const updateForm = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyContactController::update
 * @see app/Http/Controllers/Crm/CompanyContactController.php:31
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
        updateForm.patch = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Crm\CompanyContactController::destroy
 * @see app/Http/Controllers/Crm/CompanyContactController.php:41
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
export const destroy = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/companies/{company}/contacts/{contact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::destroy
 * @see app/Http/Controllers/Crm/CompanyContactController.php:41
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
destroy.url = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                    contact: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyContactController::destroy
 * @see app/Http/Controllers/Crm/CompanyContactController.php:41
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
destroy.delete = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyContactController::destroy
 * @see app/Http/Controllers/Crm/CompanyContactController.php:41
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
    const destroyForm = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyContactController::destroy
 * @see app/Http/Controllers/Crm/CompanyContactController.php:41
 * @route '/{current_team}/companies/{company}/contacts/{contact}'
 */
        destroyForm.delete = (args: { current_team: string | number, company: number | { id: number }, contact: number | { id: number } } | [current_team: string | number, company: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CompanyContactController = { store, update, destroy }

export default CompanyContactController