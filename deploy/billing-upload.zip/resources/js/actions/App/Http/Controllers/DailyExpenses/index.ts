import DailyExpenseController from './DailyExpenseController'
import PettyCashController from './PettyCashController'
const DailyExpenses = {
    DailyExpenseController: Object.assign(DailyExpenseController, DailyExpenseController),
PettyCashController: Object.assign(PettyCashController, PettyCashController),
}

export default DailyExpenses