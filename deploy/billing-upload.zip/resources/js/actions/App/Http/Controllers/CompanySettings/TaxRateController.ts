import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/tax-rates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::index
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:21
 * @route '/{current_team}/settings/tax-rates'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::store
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:49
 * @route '/{current_team}/settings/tax-rates'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/tax-rates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::store
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:49
 * @route '/{current_team}/settings/tax-rates'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::store
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:49
 * @route '/{current_team}/settings/tax-rates'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::store
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:49
 * @route '/{current_team}/settings/tax-rates'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::store
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:49
 * @route '/{current_team}/settings/tax-rates'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
export const update = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/tax-rates/{tax_rate}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
update.url = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    tax_rate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                tax_rate: typeof args.tax_rate === 'object'
                ? args.tax_rate.id
                : args.tax_rate,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{tax_rate}', parsedArgs.tax_rate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
update.put = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
update.patch = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
    const updateForm = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
        updateForm.put = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::update
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:66
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
        updateForm.patch = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::destroy
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:83
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
export const destroy = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/tax-rates/{tax_rate}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::destroy
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:83
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
destroy.url = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    tax_rate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                tax_rate: typeof args.tax_rate === 'object'
                ? args.tax_rate.id
                : args.tax_rate,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{tax_rate}', parsedArgs.tax_rate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::destroy
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:83
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
destroy.delete = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::destroy
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:83
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
    const destroyForm = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TaxRateController::destroy
 * @see app/Http/Controllers/CompanySettings/TaxRateController.php:83
 * @route '/{current_team}/settings/tax-rates/{tax_rate}'
 */
        destroyForm.delete = (args: { current_team: string | number, tax_rate: number | { id: number } } | [current_team: string | number, tax_rate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TaxRateController = { index, store, update, destroy }

export default TaxRateController