import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
export const exportMethod = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
exportMethod.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
exportMethod.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
exportMethod.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
    const exportMethodForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
        exportMethodForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::exportMethod
 * @see app/Http/Controllers/Payroll/EmployeeController.php:236
 * @route '/{current_team}/employees/export'
 */
        exportMethodForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
export const taxCertificate = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: taxCertificate.url(args, options),
    method: 'get',
})

taxCertificate.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees/{employee}/tax-certificate/{tax_year}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
taxCertificate.url = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                    tax_year: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                                tax_year: args.tax_year,
                }

    return taxCertificate.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace('{tax_year}', parsedArgs.tax_year.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
taxCertificate.get = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: taxCertificate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
taxCertificate.head = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: taxCertificate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
    const taxCertificateForm = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: taxCertificate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
        taxCertificateForm.get = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: taxCertificate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::taxCertificate
 * @see app/Http/Controllers/Payroll/EmployeeController.php:293
 * @route '/{current_team}/employees/{employee}/tax-certificate/{tax_year}'
 */
        taxCertificateForm.head = (args: { current_team: string | number, employee: number | { id: number }, tax_year: string | number } | [current_team: string | number, employee: number | { id: number }, tax_year: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: taxCertificate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    taxCertificate.form = taxCertificateForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::index
 * @see app/Http/Controllers/Payroll/EmployeeController.php:55
 * @route '/{current_team}/employees'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::create
 * @see app/Http/Controllers/Payroll/EmployeeController.php:99
 * @route '/{current_team}/employees/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::store
 * @see app/Http/Controllers/Payroll/EmployeeController.php:116
 * @route '/{current_team}/employees'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/employees',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::store
 * @see app/Http/Controllers/Payroll/EmployeeController.php:116
 * @route '/{current_team}/employees'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::store
 * @see app/Http/Controllers/Payroll/EmployeeController.php:116
 * @route '/{current_team}/employees'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::store
 * @see app/Http/Controllers/Payroll/EmployeeController.php:116
 * @route '/{current_team}/employees'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::store
 * @see app/Http/Controllers/Payroll/EmployeeController.php:116
 * @route '/{current_team}/employees'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
export const show = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees/{employee}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
show.url = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
show.get = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
show.head = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
    const showForm = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
        showForm.get = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::show
 * @see app/Http/Controllers/Payroll/EmployeeController.php:141
 * @route '/{current_team}/employees/{employee}'
 */
        showForm.head = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
export const edit = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/employees/{employee}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
edit.url = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
edit.get = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
edit.head = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
    const editForm = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
        editForm.get = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::edit
 * @see app/Http/Controllers/Payroll/EmployeeController.php:177
 * @route '/{current_team}/employees/{employee}/edit'
 */
        editForm.head = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
export const update = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/employees/{employee}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
update.url = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
update.put = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
update.patch = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
    const updateForm = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
        updateForm.put = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::update
 * @see app/Http/Controllers/Payroll/EmployeeController.php:190
 * @route '/{current_team}/employees/{employee}'
 */
        updateForm.patch = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeController.php:217
 * @route '/{current_team}/employees/{employee}'
 */
export const destroy = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/employees/{employee}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeController.php:217
 * @route '/{current_team}/employees/{employee}'
 */
destroy.url = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeController.php:217
 * @route '/{current_team}/employees/{employee}'
 */
destroy.delete = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeController.php:217
 * @route '/{current_team}/employees/{employee}'
 */
    const destroyForm = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeController.php:217
 * @route '/{current_team}/employees/{employee}'
 */
        destroyForm.delete = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const EmployeeController = { exportMethod, taxCertificate, index, create, store, show, edit, update, destroy, export: exportMethod }

export default EmployeeController