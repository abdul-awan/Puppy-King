import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\PayslipController::update
 * @see app/Http/Controllers/Payroll/PayslipController.php:32
 * @route '/{current_team}/payslips/{payslip}'
 */
export const update = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/payslips/{payslip}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::update
 * @see app/Http/Controllers/Payroll/PayslipController.php:32
 * @route '/{current_team}/payslips/{payslip}'
 */
update.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::update
 * @see app/Http/Controllers/Payroll/PayslipController.php:32
 * @route '/{current_team}/payslips/{payslip}'
 */
update.put = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::update
 * @see app/Http/Controllers/Payroll/PayslipController.php:32
 * @route '/{current_team}/payslips/{payslip}'
 */
    const updateForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::update
 * @see app/Http/Controllers/Payroll/PayslipController.php:32
 * @route '/{current_team}/payslips/{payslip}'
 */
        updateForm.put = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Payroll\PayslipController::destroy
 * @see app/Http/Controllers/Payroll/PayslipController.php:94
 * @route '/{current_team}/payslips/{payslip}'
 */
export const destroy = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/payslips/{payslip}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::destroy
 * @see app/Http/Controllers/Payroll/PayslipController.php:94
 * @route '/{current_team}/payslips/{payslip}'
 */
destroy.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::destroy
 * @see app/Http/Controllers/Payroll/PayslipController.php:94
 * @route '/{current_team}/payslips/{payslip}'
 */
destroy.delete = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::destroy
 * @see app/Http/Controllers/Payroll/PayslipController.php:94
 * @route '/{current_team}/payslips/{payslip}'
 */
    const destroyForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::destroy
 * @see app/Http/Controllers/Payroll/PayslipController.php:94
 * @route '/{current_team}/payslips/{payslip}'
 */
        destroyForm.delete = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
export const pdf = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payslips/{payslip}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
pdf.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
pdf.get = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
pdf.head = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayslipController::pdf
 * @see app/Http/Controllers/Payroll/PayslipController.php:112
 * @route '/{current_team}/payslips/{payslip}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Payroll\PayslipController::email
 * @see app/Http/Controllers/Payroll/PayslipController.php:125
 * @route '/{current_team}/payslips/{payslip}/email'
 */
export const email = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(args, options),
    method: 'post',
})

email.definition = {
    methods: ["post"],
    url: '/{current_team}/payslips/{payslip}/email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::email
 * @see app/Http/Controllers/Payroll/PayslipController.php:125
 * @route '/{current_team}/payslips/{payslip}/email'
 */
email.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return email.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::email
 * @see app/Http/Controllers/Payroll/PayslipController.php:125
 * @route '/{current_team}/payslips/{payslip}/email'
 */
email.post = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::email
 * @see app/Http/Controllers/Payroll/PayslipController.php:125
 * @route '/{current_team}/payslips/{payslip}/email'
 */
    const emailForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: email.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::email
 * @see app/Http/Controllers/Payroll/PayslipController.php:125
 * @route '/{current_team}/payslips/{payslip}/email'
 */
        emailForm.post = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: email.url(args, options),
            method: 'post',
        })
    
    email.form = emailForm
/**
* @see \App\Http\Controllers\Payroll\PayslipController::pay
 * @see app/Http/Controllers/Payroll/PayslipController.php:149
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
export const pay = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/{current_team}/payslips/{payslip}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::pay
 * @see app/Http/Controllers/Payroll/PayslipController.php:149
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
pay.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return pay.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::pay
 * @see app/Http/Controllers/Payroll/PayslipController.php:149
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
pay.post = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::pay
 * @see app/Http/Controllers/Payroll/PayslipController.php:149
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
    const payForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pay.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::pay
 * @see app/Http/Controllers/Payroll/PayslipController.php:149
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
        payForm.post = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pay.url(args, options),
            method: 'post',
        })
    
    pay.form = payForm
/**
* @see \App\Http\Controllers\Payroll\PayslipController::unpay
 * @see app/Http/Controllers/Payroll/PayslipController.php:173
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
export const unpay = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unpay.url(args, options),
    method: 'delete',
})

unpay.definition = {
    methods: ["delete"],
    url: '/{current_team}/payslips/{payslip}/pay',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\PayslipController::unpay
 * @see app/Http/Controllers/Payroll/PayslipController.php:173
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
unpay.url = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payslip: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payslip: typeof args.payslip === 'object'
                ? args.payslip.id
                : args.payslip,
                }

    return unpay.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayslipController::unpay
 * @see app/Http/Controllers/Payroll/PayslipController.php:173
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
unpay.delete = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unpay.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\PayslipController::unpay
 * @see app/Http/Controllers/Payroll/PayslipController.php:173
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
    const unpayForm = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unpay.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayslipController::unpay
 * @see app/Http/Controllers/Payroll/PayslipController.php:173
 * @route '/{current_team}/payslips/{payslip}/pay'
 */
        unpayForm.delete = (args: { current_team: string | number, payslip: number | { id: number } } | [current_team: string | number, payslip: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unpay.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unpay.form = unpayForm
const PayslipController = { update, destroy, pdf, email, pay, unpay }

export default PayslipController