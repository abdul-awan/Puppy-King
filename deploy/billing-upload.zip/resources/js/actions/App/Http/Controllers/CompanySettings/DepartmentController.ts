import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
export const logo = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logo.url(args, options),
    method: 'get',
})

logo.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/departments/{department}/logo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
logo.url = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    department: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return logo.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
logo.get = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logo.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
logo.head = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logo.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
    const logoForm = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: logo.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
        logoForm.get = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logo.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::logo
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:124
 * @route '/{current_team}/settings/departments/{department}/logo'
 */
        logoForm.head = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logo.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    logo.form = logoForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/departments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::index
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:28
 * @route '/{current_team}/settings/departments'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/departments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::create
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:42
 * @route '/{current_team}/settings/departments/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::store
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:53
 * @route '/{current_team}/settings/departments'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/departments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::store
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:53
 * @route '/{current_team}/settings/departments'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::store
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:53
 * @route '/{current_team}/settings/departments'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::store
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:53
 * @route '/{current_team}/settings/departments'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::store
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:53
 * @route '/{current_team}/settings/departments'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
export const edit = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/departments/{department}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
edit.url = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    department: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
edit.get = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
edit.head = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
    const editForm = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
        editForm.get = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::edit
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:71
 * @route '/{current_team}/settings/departments/{department}/edit'
 */
        editForm.head = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
export const update = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/departments/{department}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
update.url = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    department: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
update.put = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
update.patch = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
    const updateForm = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
        updateForm.put = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::update
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:82
 * @route '/{current_team}/settings/departments/{department}'
 */
        updateForm.patch = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::destroy
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:106
 * @route '/{current_team}/settings/departments/{department}'
 */
export const destroy = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/departments/{department}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::destroy
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:106
 * @route '/{current_team}/settings/departments/{department}'
 */
destroy.url = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    department: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::destroy
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:106
 * @route '/{current_team}/settings/departments/{department}'
 */
destroy.delete = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::destroy
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:106
 * @route '/{current_team}/settings/departments/{department}'
 */
    const destroyForm = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DepartmentController::destroy
 * @see app/Http/Controllers/CompanySettings/DepartmentController.php:106
 * @route '/{current_team}/settings/departments/{department}'
 */
        destroyForm.delete = (args: { current_team: string | number, department: number | { id: number } } | [current_team: string | number, department: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DepartmentController = { logo, index, create, store, edit, update, destroy }

export default DepartmentController