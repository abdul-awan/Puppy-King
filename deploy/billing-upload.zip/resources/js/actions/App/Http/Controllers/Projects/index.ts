import ProjectController from './ProjectController'
import MilestoneController from './MilestoneController'
import ProjectMaterialController from './ProjectMaterialController'
import TaskController from './TaskController'
const Projects = {
    ProjectController: Object.assign(ProjectController, ProjectController),
MilestoneController: Object.assign(MilestoneController, MilestoneController),
ProjectMaterialController: Object.assign(ProjectMaterialController, ProjectMaterialController),
TaskController: Object.assign(TaskController, TaskController),
}

export default Projects