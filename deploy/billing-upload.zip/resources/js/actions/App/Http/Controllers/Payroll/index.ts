import MyPayslipController from './MyPayslipController'
import EmployeeController from './EmployeeController'
import EmployeeAdvanceController from './EmployeeAdvanceController'
import PayrollRunController from './PayrollRunController'
import PayslipController from './PayslipController'
const Payroll = {
    MyPayslipController: Object.assign(MyPayslipController, MyPayslipController),
EmployeeController: Object.assign(EmployeeController, EmployeeController),
EmployeeAdvanceController: Object.assign(EmployeeAdvanceController, EmployeeAdvanceController),
PayrollRunController: Object.assign(PayrollRunController, PayrollRunController),
PayslipController: Object.assign(PayslipController, PayslipController),
}

export default Payroll