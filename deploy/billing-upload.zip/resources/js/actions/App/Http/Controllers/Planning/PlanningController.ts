import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/planning',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Planning\PlanningController::index
 * @see app/Http/Controllers/Planning/PlanningController.php:29
 * @route '/{current_team}/planning'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Planning\PlanningController::plan
 * @see app/Http/Controllers/Planning/PlanningController.php:167
 * @route '/{current_team}/planning/tasks/{task}'
 */
export const plan = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: plan.url(args, options),
    method: 'patch',
})

plan.definition = {
    methods: ["patch"],
    url: '/{current_team}/planning/tasks/{task}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Planning\PlanningController::plan
 * @see app/Http/Controllers/Planning/PlanningController.php:167
 * @route '/{current_team}/planning/tasks/{task}'
 */
plan.url = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    task: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return plan.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Planning\PlanningController::plan
 * @see app/Http/Controllers/Planning/PlanningController.php:167
 * @route '/{current_team}/planning/tasks/{task}'
 */
plan.patch = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: plan.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Planning\PlanningController::plan
 * @see app/Http/Controllers/Planning/PlanningController.php:167
 * @route '/{current_team}/planning/tasks/{task}'
 */
    const planForm = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: plan.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Planning\PlanningController::plan
 * @see app/Http/Controllers/Planning/PlanningController.php:167
 * @route '/{current_team}/planning/tasks/{task}'
 */
        planForm.patch = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: plan.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    plan.form = planForm
const PlanningController = { index, plan }

export default PlanningController