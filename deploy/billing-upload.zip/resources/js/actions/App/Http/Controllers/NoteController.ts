import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NoteController::store
 * @see app/Http/Controllers/NoteController.php:20
 * @route '/{current_team}/notes'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/notes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NoteController::store
 * @see app/Http/Controllers/NoteController.php:20
 * @route '/{current_team}/notes'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoteController::store
 * @see app/Http/Controllers/NoteController.php:20
 * @route '/{current_team}/notes'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NoteController::store
 * @see app/Http/Controllers/NoteController.php:20
 * @route '/{current_team}/notes'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NoteController::store
 * @see app/Http/Controllers/NoteController.php:20
 * @route '/{current_team}/notes'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\NoteController::update
 * @see app/Http/Controllers/NoteController.php:42
 * @route '/{current_team}/notes/{note}'
 */
export const update = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/{current_team}/notes/{note}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NoteController::update
 * @see app/Http/Controllers/NoteController.php:42
 * @route '/{current_team}/notes/{note}'
 */
update.url = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                note: typeof args.note === 'object'
                ? args.note.id
                : args.note,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoteController::update
 * @see app/Http/Controllers/NoteController.php:42
 * @route '/{current_team}/notes/{note}'
 */
update.patch = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NoteController::update
 * @see app/Http/Controllers/NoteController.php:42
 * @route '/{current_team}/notes/{note}'
 */
    const updateForm = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NoteController::update
 * @see app/Http/Controllers/NoteController.php:42
 * @route '/{current_team}/notes/{note}'
 */
        updateForm.patch = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\NoteController::destroy
 * @see app/Http/Controllers/NoteController.php:57
 * @route '/{current_team}/notes/{note}'
 */
export const destroy = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/notes/{note}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\NoteController::destroy
 * @see app/Http/Controllers/NoteController.php:57
 * @route '/{current_team}/notes/{note}'
 */
destroy.url = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                note: typeof args.note === 'object'
                ? args.note.id
                : args.note,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoteController::destroy
 * @see app/Http/Controllers/NoteController.php:57
 * @route '/{current_team}/notes/{note}'
 */
destroy.delete = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\NoteController::destroy
 * @see app/Http/Controllers/NoteController.php:57
 * @route '/{current_team}/notes/{note}'
 */
    const destroyForm = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NoteController::destroy
 * @see app/Http/Controllers/NoteController.php:57
 * @route '/{current_team}/notes/{note}'
 */
        destroyForm.delete = (args: { current_team: string | number, note: number | { id: number } } | [current_team: string | number, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const NoteController = { store, update, destroy }

export default NoteController