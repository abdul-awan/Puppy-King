import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DealController::move
 * @see app/Http/Controllers/DealController.php:176
 * @route '/{current_team}/deals/{deal}/move'
 */
export const move = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

move.definition = {
    methods: ["patch"],
    url: '/{current_team}/deals/{deal}/move',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DealController::move
 * @see app/Http/Controllers/DealController.php:176
 * @route '/{current_team}/deals/{deal}/move'
 */
move.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return move.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::move
 * @see app/Http/Controllers/DealController.php:176
 * @route '/{current_team}/deals/{deal}/move'
 */
move.patch = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: move.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DealController::move
 * @see app/Http/Controllers/DealController.php:176
 * @route '/{current_team}/deals/{deal}/move'
 */
    const moveForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: move.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::move
 * @see app/Http/Controllers/DealController.php:176
 * @route '/{current_team}/deals/{deal}/move'
 */
        moveForm.patch = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: move.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    move.form = moveForm
/**
* @see \App\Http\Controllers\DealController::won
 * @see app/Http/Controllers/DealController.php:216
 * @route '/{current_team}/deals/{deal}/won'
 */
export const won = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: won.url(args, options),
    method: 'post',
})

won.definition = {
    methods: ["post"],
    url: '/{current_team}/deals/{deal}/won',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DealController::won
 * @see app/Http/Controllers/DealController.php:216
 * @route '/{current_team}/deals/{deal}/won'
 */
won.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return won.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::won
 * @see app/Http/Controllers/DealController.php:216
 * @route '/{current_team}/deals/{deal}/won'
 */
won.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: won.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DealController::won
 * @see app/Http/Controllers/DealController.php:216
 * @route '/{current_team}/deals/{deal}/won'
 */
    const wonForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: won.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::won
 * @see app/Http/Controllers/DealController.php:216
 * @route '/{current_team}/deals/{deal}/won'
 */
        wonForm.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: won.url(args, options),
            method: 'post',
        })
    
    won.form = wonForm
/**
* @see \App\Http\Controllers\DealController::lost
 * @see app/Http/Controllers/DealController.php:230
 * @route '/{current_team}/deals/{deal}/lost'
 */
export const lost = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lost.url(args, options),
    method: 'post',
})

lost.definition = {
    methods: ["post"],
    url: '/{current_team}/deals/{deal}/lost',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DealController::lost
 * @see app/Http/Controllers/DealController.php:230
 * @route '/{current_team}/deals/{deal}/lost'
 */
lost.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return lost.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::lost
 * @see app/Http/Controllers/DealController.php:230
 * @route '/{current_team}/deals/{deal}/lost'
 */
lost.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lost.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DealController::lost
 * @see app/Http/Controllers/DealController.php:230
 * @route '/{current_team}/deals/{deal}/lost'
 */
    const lostForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: lost.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::lost
 * @see app/Http/Controllers/DealController.php:230
 * @route '/{current_team}/deals/{deal}/lost'
 */
        lostForm.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: lost.url(args, options),
            method: 'post',
        })
    
    lost.form = lostForm
/**
* @see \App\Http\Controllers\DealController::reopen
 * @see app/Http/Controllers/DealController.php:256
 * @route '/{current_team}/deals/{deal}/reopen'
 */
export const reopen = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

reopen.definition = {
    methods: ["post"],
    url: '/{current_team}/deals/{deal}/reopen',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DealController::reopen
 * @see app/Http/Controllers/DealController.php:256
 * @route '/{current_team}/deals/{deal}/reopen'
 */
reopen.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return reopen.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::reopen
 * @see app/Http/Controllers/DealController.php:256
 * @route '/{current_team}/deals/{deal}/reopen'
 */
reopen.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DealController::reopen
 * @see app/Http/Controllers/DealController.php:256
 * @route '/{current_team}/deals/{deal}/reopen'
 */
    const reopenForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reopen.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::reopen
 * @see app/Http/Controllers/DealController.php:256
 * @route '/{current_team}/deals/{deal}/reopen'
 */
        reopenForm.post = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reopen.url(args, options),
            method: 'post',
        })
    
    reopen.form = reopenForm
/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/deals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:34
 * @route '/{current_team}/deals'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/deals/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::create
 * @see app/Http/Controllers/DealController.php:90
 * @route '/{current_team}/deals/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:108
 * @route '/{current_team}/deals'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/deals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:108
 * @route '/{current_team}/deals'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:108
 * @route '/{current_team}/deals'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:108
 * @route '/{current_team}/deals'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:108
 * @route '/{current_team}/deals'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
export const show = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/deals/{deal}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
show.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
show.get = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
show.head = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
    const showForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
        showForm.get = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:130
 * @route '/{current_team}/deals/{deal}'
 */
        showForm.head = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
export const edit = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/deals/{deal}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
edit.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
edit.get = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
edit.head = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
    const editForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
        editForm.get = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::edit
 * @see app/Http/Controllers/DealController.php:148
 * @route '/{current_team}/deals/{deal}/edit'
 */
        editForm.head = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
export const update = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/deals/{deal}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
update.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
update.put = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
update.patch = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
    const updateForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
        updateForm.put = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:161
 * @route '/{current_team}/deals/{deal}'
 */
        updateForm.patch = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:268
 * @route '/{current_team}/deals/{deal}'
 */
export const destroy = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/deals/{deal}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:268
 * @route '/{current_team}/deals/{deal}'
 */
destroy.url = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:268
 * @route '/{current_team}/deals/{deal}'
 */
destroy.delete = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:268
 * @route '/{current_team}/deals/{deal}'
 */
    const destroyForm = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:268
 * @route '/{current_team}/deals/{deal}'
 */
        destroyForm.delete = (args: { current_team: string | number, deal: number | { id: number } } | [current_team: string | number, deal: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DealController = { move, won, lost, reopen, index, create, store, show, edit, update, destroy }

export default DealController