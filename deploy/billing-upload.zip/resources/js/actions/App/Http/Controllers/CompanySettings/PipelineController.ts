import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/pipelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::index
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:25
 * @route '/{current_team}/settings/pipelines'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::store
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:55
 * @route '/{current_team}/settings/pipelines'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/pipelines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::store
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:55
 * @route '/{current_team}/settings/pipelines'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::store
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:55
 * @route '/{current_team}/settings/pipelines'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::store
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:55
 * @route '/{current_team}/settings/pipelines'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::store
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:55
 * @route '/{current_team}/settings/pipelines'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::update
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:77
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
export const update = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/pipelines/{pipeline}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::update
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:77
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
update.url = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pipeline: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pipeline: typeof args.pipeline === 'object'
                ? args.pipeline.id
                : args.pipeline,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::update
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:77
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
update.put = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::update
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:77
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
    const updateForm = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::update
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:77
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
        updateForm.put = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroy
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:98
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
export const destroy = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/pipelines/{pipeline}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroy
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:98
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
destroy.url = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pipeline: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pipeline: typeof args.pipeline === 'object'
                ? args.pipeline.id
                : args.pipeline,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroy
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:98
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
destroy.delete = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroy
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:98
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
    const destroyForm = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroy
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:98
 * @route '/{current_team}/settings/pipelines/{pipeline}'
 */
        destroyForm.delete = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::storePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:125
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases'
 */
export const storePhase = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePhase.url(args, options),
    method: 'post',
})

storePhase.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/pipelines/{pipeline}/phases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::storePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:125
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases'
 */
storePhase.url = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pipeline: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pipeline: typeof args.pipeline === 'object'
                ? args.pipeline.id
                : args.pipeline,
                }

    return storePhase.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::storePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:125
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases'
 */
storePhase.post = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePhase.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::storePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:125
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases'
 */
    const storePhaseForm = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePhase.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::storePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:125
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases'
 */
        storePhaseForm.post = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePhase.url(args, options),
            method: 'post',
        })
    
    storePhase.form = storePhaseForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::orderPhases
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:169
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases/order'
 */
export const orderPhases = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: orderPhases.url(args, options),
    method: 'put',
})

orderPhases.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/pipelines/{pipeline}/phases/order',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::orderPhases
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:169
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases/order'
 */
orderPhases.url = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pipeline: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pipeline: typeof args.pipeline === 'object'
                ? args.pipeline.id
                : args.pipeline,
                }

    return orderPhases.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::orderPhases
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:169
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases/order'
 */
orderPhases.put = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: orderPhases.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::orderPhases
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:169
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases/order'
 */
    const orderPhasesForm = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: orderPhases.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::orderPhases
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:169
 * @route '/{current_team}/settings/pipelines/{pipeline}/phases/order'
 */
        orderPhasesForm.put = (args: { current_team: string | number, pipeline: number | { id: number } } | [current_team: string | number, pipeline: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: orderPhases.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    orderPhases.form = orderPhasesForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::updatePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:141
 * @route '/{current_team}/settings/phases/{phase}'
 */
export const updatePhase = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePhase.url(args, options),
    method: 'put',
})

updatePhase.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/phases/{phase}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::updatePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:141
 * @route '/{current_team}/settings/phases/{phase}'
 */
updatePhase.url = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return updatePhase.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::updatePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:141
 * @route '/{current_team}/settings/phases/{phase}'
 */
updatePhase.put = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePhase.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::updatePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:141
 * @route '/{current_team}/settings/phases/{phase}'
 */
    const updatePhaseForm = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePhase.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::updatePhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:141
 * @route '/{current_team}/settings/phases/{phase}'
 */
        updatePhaseForm.put = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePhase.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePhase.form = updatePhaseForm
/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroyPhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:151
 * @route '/{current_team}/settings/phases/{phase}'
 */
export const destroyPhase = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhase.url(args, options),
    method: 'delete',
})

destroyPhase.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/phases/{phase}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroyPhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:151
 * @route '/{current_team}/settings/phases/{phase}'
 */
destroyPhase.url = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return destroyPhase.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroyPhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:151
 * @route '/{current_team}/settings/phases/{phase}'
 */
destroyPhase.delete = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhase.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroyPhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:151
 * @route '/{current_team}/settings/phases/{phase}'
 */
    const destroyPhaseForm = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyPhase.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PipelineController::destroyPhase
 * @see app/Http/Controllers/CompanySettings/PipelineController.php:151
 * @route '/{current_team}/settings/phases/{phase}'
 */
        destroyPhaseForm.delete = (args: { current_team: string | number, phase: number | { id: number } } | [current_team: string | number, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyPhase.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyPhase.form = destroyPhaseForm
const PipelineController = { index, store, update, destroy, storePhase, orderPhases, updatePhase, destroyPhase }

export default PipelineController