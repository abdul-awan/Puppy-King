import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
export const show = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/p/t/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
show.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return show.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
show.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
show.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
    const showForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
        showForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::show
 * @see app/Http/Controllers/Portal/TicketPortalController.php:35
 * @route '/p/t/{token}'
 */
        showForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::reply
 * @see app/Http/Controllers/Portal/TicketPortalController.php:65
 * @route '/p/t/{token}'
 */
export const reply = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

reply.definition = {
    methods: ["post"],
    url: '/p/t/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::reply
 * @see app/Http/Controllers/Portal/TicketPortalController.php:65
 * @route '/p/t/{token}'
 */
reply.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return reply.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::reply
 * @see app/Http/Controllers/Portal/TicketPortalController.php:65
 * @route '/p/t/{token}'
 */
reply.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Portal\TicketPortalController::reply
 * @see app/Http/Controllers/Portal/TicketPortalController.php:65
 * @route '/p/t/{token}'
 */
    const replyForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reply.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::reply
 * @see app/Http/Controllers/Portal/TicketPortalController.php:65
 * @route '/p/t/{token}'
 */
        replyForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reply.url(args, options),
            method: 'post',
        })
    
    reply.form = replyForm
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
export const supportForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supportForm.url(args, options),
    method: 'get',
})

supportForm.definition = {
    methods: ["get","head"],
    url: '/p/support/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
supportForm.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return supportForm.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
supportForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supportForm.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
supportForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: supportForm.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
    const supportFormForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: supportForm.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
        supportFormForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supportForm.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::supportForm
 * @see app/Http/Controllers/Portal/TicketPortalController.php:84
 * @route '/p/support/{token}'
 */
        supportFormForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supportForm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    supportForm.form = supportFormForm
/**
* @see \App\Http\Controllers\Portal\TicketPortalController::submit
 * @see app/Http/Controllers/Portal/TicketPortalController.php:97
 * @route '/p/support/{token}'
 */
export const submit = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/p/support/{token}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::submit
 * @see app/Http/Controllers/Portal/TicketPortalController.php:97
 * @route '/p/support/{token}'
 */
submit.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return submit.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\TicketPortalController::submit
 * @see app/Http/Controllers/Portal/TicketPortalController.php:97
 * @route '/p/support/{token}'
 */
submit.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Portal\TicketPortalController::submit
 * @see app/Http/Controllers/Portal/TicketPortalController.php:97
 * @route '/p/support/{token}'
 */
    const submitForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Portal\TicketPortalController::submit
 * @see app/Http/Controllers/Portal/TicketPortalController.php:97
 * @route '/p/support/{token}'
 */
        submitForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
const TicketPortalController = { show, reply, supportForm, submit }

export default TicketPortalController