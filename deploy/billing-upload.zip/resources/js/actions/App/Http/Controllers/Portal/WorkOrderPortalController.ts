import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
export const show = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/p/w/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
show.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return show.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
show.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
show.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
    const showForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
        showForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::show
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:31
 * @route '/p/w/{token}'
 */
        showForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
export const pdf = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/p/w/{token}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
pdf.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return pdf.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
pdf.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
pdf.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
    const pdfForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
        pdfForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::pdf
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:105
 * @route '/p/w/{token}/pdf'
 */
        pdfForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::sign
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:118
 * @route '/p/w/{token}/sign'
 */
export const sign = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sign.url(args, options),
    method: 'post',
})

sign.definition = {
    methods: ["post"],
    url: '/p/w/{token}/sign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::sign
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:118
 * @route '/p/w/{token}/sign'
 */
sign.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return sign.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::sign
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:118
 * @route '/p/w/{token}/sign'
 */
sign.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sign.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::sign
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:118
 * @route '/p/w/{token}/sign'
 */
    const signForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sign.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Portal\WorkOrderPortalController::sign
 * @see app/Http/Controllers/Portal/WorkOrderPortalController.php:118
 * @route '/p/w/{token}/sign'
 */
        signForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sign.url(args, options),
            method: 'post',
        })
    
    sign.form = signForm
const WorkOrderPortalController = { show, pdf, sign }

export default WorkOrderPortalController