import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
export const edit = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/invoice-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
edit.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
edit.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
edit.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
    const editForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
        editForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:34
 * @route '/{current_team}/settings/invoice-settings'
 */
        editForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::update
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:65
 * @route '/{current_team}/settings/invoice-settings'
 */
export const update = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/invoice-settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::update
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:65
 * @route '/{current_team}/settings/invoice-settings'
 */
update.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::update
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:65
 * @route '/{current_team}/settings/invoice-settings'
 */
update.put = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::update
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:65
 * @route '/{current_team}/settings/invoice-settings'
 */
    const updateForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::update
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:65
 * @route '/{current_team}/settings/invoice-settings'
 */
        updateForm.put = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
export const preview = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/invoice-settings/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
preview.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return preview.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
preview.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
preview.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
    const previewForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
        previewForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\InvoiceSettingsController::preview
 * @see app/Http/Controllers/CompanySettings/InvoiceSettingsController.php:98
 * @route '/{current_team}/settings/invoice-settings/preview'
 */
        previewForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
const InvoiceSettingsController = { edit, update, preview }

export default InvoiceSettingsController