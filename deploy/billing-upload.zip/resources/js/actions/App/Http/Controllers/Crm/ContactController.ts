import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Crm\ContactController::archive
 * @see app/Http/Controllers/Crm/ContactController.php:149
 * @route '/{current_team}/contacts/{contact}/archive'
 */
export const archive = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

archive.definition = {
    methods: ["patch"],
    url: '/{current_team}/contacts/{contact}/archive',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::archive
 * @see app/Http/Controllers/Crm/ContactController.php:149
 * @route '/{current_team}/contacts/{contact}/archive'
 */
archive.url = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return archive.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::archive
 * @see app/Http/Controllers/Crm/ContactController.php:149
 * @route '/{current_team}/contacts/{contact}/archive'
 */
archive.patch = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::archive
 * @see app/Http/Controllers/Crm/ContactController.php:149
 * @route '/{current_team}/contacts/{contact}/archive'
 */
    const archiveForm = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::archive
 * @see app/Http/Controllers/Crm/ContactController.php:149
 * @route '/{current_team}/contacts/{contact}/archive'
 */
        archiveForm.patch = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\ContactController::index
 * @see app/Http/Controllers/Crm/ContactController.php:28
 * @route '/{current_team}/contacts'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/contacts/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\ContactController::create
 * @see app/Http/Controllers/Crm/ContactController.php:67
 * @route '/{current_team}/contacts/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Crm\ContactController::store
 * @see app/Http/Controllers/Crm/ContactController.php:82
 * @route '/{current_team}/contacts'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/contacts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::store
 * @see app/Http/Controllers/Crm/ContactController.php:82
 * @route '/{current_team}/contacts'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::store
 * @see app/Http/Controllers/Crm/ContactController.php:82
 * @route '/{current_team}/contacts'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::store
 * @see app/Http/Controllers/Crm/ContactController.php:82
 * @route '/{current_team}/contacts'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::store
 * @see app/Http/Controllers/Crm/ContactController.php:82
 * @route '/{current_team}/contacts'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
export const show = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/contacts/{contact}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
show.url = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
show.get = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
show.head = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
    const showForm = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
        showForm.get = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\ContactController::show
 * @see app/Http/Controllers/Crm/ContactController.php:102
 * @route '/{current_team}/contacts/{contact}'
 */
        showForm.head = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
export const edit = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/contacts/{contact}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
edit.url = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
edit.get = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
edit.head = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
    const editForm = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
        editForm.get = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\ContactController::edit
 * @see app/Http/Controllers/Crm/ContactController.php:118
 * @route '/{current_team}/contacts/{contact}/edit'
 */
        editForm.head = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
export const update = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/contacts/{contact}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
update.url = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
update.put = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
update.patch = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
    const updateForm = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
        updateForm.put = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Crm\ContactController::update
 * @see app/Http/Controllers/Crm/ContactController.php:131
 * @route '/{current_team}/contacts/{contact}'
 */
        updateForm.patch = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Crm\ContactController::destroy
 * @see app/Http/Controllers/Crm/ContactController.php:163
 * @route '/{current_team}/contacts/{contact}'
 */
export const destroy = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/contacts/{contact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Crm\ContactController::destroy
 * @see app/Http/Controllers/Crm/ContactController.php:163
 * @route '/{current_team}/contacts/{contact}'
 */
destroy.url = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\ContactController::destroy
 * @see app/Http/Controllers/Crm/ContactController.php:163
 * @route '/{current_team}/contacts/{contact}'
 */
destroy.delete = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Crm\ContactController::destroy
 * @see app/Http/Controllers/Crm/ContactController.php:163
 * @route '/{current_team}/contacts/{contact}'
 */
    const destroyForm = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\ContactController::destroy
 * @see app/Http/Controllers/Crm/ContactController.php:163
 * @route '/{current_team}/contacts/{contact}'
 */
        destroyForm.delete = (args: { current_team: string | number, contact: number | { id: number } } | [current_team: string | number, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ContactController = { archive, index, create, store, show, edit, update, destroy }

export default ContactController