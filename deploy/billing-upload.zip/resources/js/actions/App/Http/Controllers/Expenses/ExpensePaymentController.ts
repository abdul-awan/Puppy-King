import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::store
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:21
 * @route '/{current_team}/expenses/{expense}/payments'
 */
export const store = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/expenses/{expense}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::store
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:21
 * @route '/{current_team}/expenses/{expense}/payments'
 */
store.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::store
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:21
 * @route '/{current_team}/expenses/{expense}/payments'
 */
store.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::store
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:21
 * @route '/{current_team}/expenses/{expense}/payments'
 */
    const storeForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::store
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:21
 * @route '/{current_team}/expenses/{expense}/payments'
 */
        storeForm.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::destroy
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:56
 * @route '/{current_team}/expenses/{expense}/payments/{payment}'
 */
export const destroy = (args: { current_team: string | number, expense: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, expense: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/expenses/{expense}/payments/{payment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::destroy
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:56
 * @route '/{current_team}/expenses/{expense}/payments/{payment}'
 */
destroy.url = (args: { current_team: string | number, expense: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, expense: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                    payment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                                payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::destroy
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:56
 * @route '/{current_team}/expenses/{expense}/payments/{payment}'
 */
destroy.delete = (args: { current_team: string | number, expense: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, expense: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::destroy
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:56
 * @route '/{current_team}/expenses/{expense}/payments/{payment}'
 */
    const destroyForm = (args: { current_team: string | number, expense: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, expense: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpensePaymentController::destroy
 * @see app/Http/Controllers/Expenses/ExpensePaymentController.php:56
 * @route '/{current_team}/expenses/{expense}/payments/{payment}'
 */
        destroyForm.delete = (args: { current_team: string | number, expense: number | { id: number }, payment: number | { id: number } } | [current_team: string | number, expense: number | { id: number }, payment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ExpensePaymentController = { store, destroy }

export default ExpensePaymentController