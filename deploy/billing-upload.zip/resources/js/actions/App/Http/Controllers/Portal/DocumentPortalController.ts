import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
export const invoice = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoice.url(args, options),
    method: 'get',
})

invoice.definition = {
    methods: ["get","head"],
    url: '/p/i/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
invoice.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return invoice.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
invoice.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoice.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
invoice.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: invoice.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
    const invoiceForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: invoice.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
        invoiceForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoice.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoice
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:33
 * @route '/p/i/{token}'
 */
        invoiceForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoice.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    invoice.form = invoiceForm
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
export const invoicePdf = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoicePdf.url(args, options),
    method: 'get',
})

invoicePdf.definition = {
    methods: ["get","head"],
    url: '/p/i/{token}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
invoicePdf.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return invoicePdf.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
invoicePdf.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoicePdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
invoicePdf.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: invoicePdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
    const invoicePdfForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: invoicePdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
        invoicePdfForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoicePdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::invoicePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:52
 * @route '/p/i/{token}/pdf'
 */
        invoicePdfForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoicePdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    invoicePdf.form = invoicePdfForm
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
export const creditNote = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: creditNote.url(args, options),
    method: 'get',
})

creditNote.definition = {
    methods: ["get","head"],
    url: '/p/c/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
creditNote.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return creditNote.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
creditNote.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: creditNote.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
creditNote.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: creditNote.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
    const creditNoteForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: creditNote.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
        creditNoteForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: creditNote.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNote
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:60
 * @route '/p/c/{token}'
 */
        creditNoteForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: creditNote.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    creditNote.form = creditNoteForm
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
export const creditNotePdf = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: creditNotePdf.url(args, options),
    method: 'get',
})

creditNotePdf.definition = {
    methods: ["get","head"],
    url: '/p/c/{token}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
creditNotePdf.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return creditNotePdf.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
creditNotePdf.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: creditNotePdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
creditNotePdf.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: creditNotePdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
    const creditNotePdfForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: creditNotePdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
        creditNotePdfForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: creditNotePdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\DocumentPortalController::creditNotePdf
 * @see app/Http/Controllers/Portal/DocumentPortalController.php:75
 * @route '/p/c/{token}/pdf'
 */
        creditNotePdfForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: creditNotePdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    creditNotePdf.form = creditNotePdfForm
const DocumentPortalController = { invoice, invoicePdf, creditNote, creditNotePdf }

export default DocumentPortalController