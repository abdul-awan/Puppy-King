import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
const SearchController = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SearchController.url(args, options),
    method: 'get',
})

SearchController.definition = {
    methods: ["get","head"],
    url: '/{current_team}/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
SearchController.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return SearchController.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
SearchController.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SearchController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
SearchController.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SearchController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
    const SearchControllerForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: SearchController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
        SearchControllerForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SearchController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SearchController::__invoke
 * @see app/Http/Controllers/SearchController.php:37
 * @route '/{current_team}/search'
 */
        SearchControllerForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SearchController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    SearchController.form = SearchControllerForm
export default SearchController