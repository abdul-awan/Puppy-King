import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Projects\TaskController::index
 * @see app/Http/Controllers/Projects/TaskController.php:25
 * @route '/{current_team}/tasks'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Projects\TaskController::store
 * @see app/Http/Controllers/Projects/TaskController.php:73
 * @route '/{current_team}/tasks'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/tasks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Projects\TaskController::store
 * @see app/Http/Controllers/Projects/TaskController.php:73
 * @route '/{current_team}/tasks'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\TaskController::store
 * @see app/Http/Controllers/Projects/TaskController.php:73
 * @route '/{current_team}/tasks'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Projects\TaskController::store
 * @see app/Http/Controllers/Projects/TaskController.php:73
 * @route '/{current_team}/tasks'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\TaskController::store
 * @see app/Http/Controllers/Projects/TaskController.php:73
 * @route '/{current_team}/tasks'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Projects\TaskController::update
 * @see app/Http/Controllers/Projects/TaskController.php:88
 * @route '/{current_team}/tasks/{task}'
 */
export const update = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/tasks/{task}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Projects\TaskController::update
 * @see app/Http/Controllers/Projects/TaskController.php:88
 * @route '/{current_team}/tasks/{task}'
 */
update.url = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    task: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\TaskController::update
 * @see app/Http/Controllers/Projects/TaskController.php:88
 * @route '/{current_team}/tasks/{task}'
 */
update.put = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Projects\TaskController::update
 * @see app/Http/Controllers/Projects/TaskController.php:88
 * @route '/{current_team}/tasks/{task}'
 */
    const updateForm = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\TaskController::update
 * @see app/Http/Controllers/Projects/TaskController.php:88
 * @route '/{current_team}/tasks/{task}'
 */
        updateForm.put = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Projects\TaskController::complete
 * @see app/Http/Controllers/Projects/TaskController.php:104
 * @route '/{current_team}/tasks/{task}/complete'
 */
export const complete = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

complete.definition = {
    methods: ["patch"],
    url: '/{current_team}/tasks/{task}/complete',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Projects\TaskController::complete
 * @see app/Http/Controllers/Projects/TaskController.php:104
 * @route '/{current_team}/tasks/{task}/complete'
 */
complete.url = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    task: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return complete.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\TaskController::complete
 * @see app/Http/Controllers/Projects/TaskController.php:104
 * @route '/{current_team}/tasks/{task}/complete'
 */
complete.patch = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Projects\TaskController::complete
 * @see app/Http/Controllers/Projects/TaskController.php:104
 * @route '/{current_team}/tasks/{task}/complete'
 */
    const completeForm = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\TaskController::complete
 * @see app/Http/Controllers/Projects/TaskController.php:104
 * @route '/{current_team}/tasks/{task}/complete'
 */
        completeForm.patch = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\Projects\TaskController::destroy
 * @see app/Http/Controllers/Projects/TaskController.php:115
 * @route '/{current_team}/tasks/{task}'
 */
export const destroy = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/tasks/{task}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Projects\TaskController::destroy
 * @see app/Http/Controllers/Projects/TaskController.php:115
 * @route '/{current_team}/tasks/{task}'
 */
destroy.url = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    task: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\TaskController::destroy
 * @see app/Http/Controllers/Projects/TaskController.php:115
 * @route '/{current_team}/tasks/{task}'
 */
destroy.delete = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Projects\TaskController::destroy
 * @see app/Http/Controllers/Projects/TaskController.php:115
 * @route '/{current_team}/tasks/{task}'
 */
    const destroyForm = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\TaskController::destroy
 * @see app/Http/Controllers/Projects/TaskController.php:115
 * @route '/{current_team}/tasks/{task}'
 */
        destroyForm.delete = (args: { current_team: string | number, task: number | { id: number } } | [current_team: string | number, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TaskController = { index, store, update, complete, destroy }

export default TaskController