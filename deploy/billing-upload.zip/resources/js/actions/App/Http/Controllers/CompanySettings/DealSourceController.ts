import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/deal-sources',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::index
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:38
 * @route '/{current_team}/settings/deal-sources'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::store
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:50
 * @route '/{current_team}/settings/deal-sources'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/deal-sources',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::store
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:50
 * @route '/{current_team}/settings/deal-sources'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::store
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:50
 * @route '/{current_team}/settings/deal-sources'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::store
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:50
 * @route '/{current_team}/settings/deal-sources'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::store
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:50
 * @route '/{current_team}/settings/deal-sources'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
export const update = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/deal-sources/{deal_source}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
update.url = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal_source: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal_source: args.deal_source,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal_source}', parsedArgs.deal_source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
update.put = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
update.patch = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
    const updateForm = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
        updateForm.put = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::update
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:63
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
        updateForm.patch = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::destroy
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:76
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
export const destroy = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/deal-sources/{deal_source}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::destroy
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:76
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
destroy.url = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    deal_source: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                deal_source: args.deal_source,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{deal_source}', parsedArgs.deal_source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::destroy
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:76
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
destroy.delete = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::destroy
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:76
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
    const destroyForm = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DealSourceController::destroy
 * @see app/Http/Controllers/CompanySettings/DealSourceController.php:76
 * @route '/{current_team}/settings/deal-sources/{deal_source}'
 */
        destroyForm.delete = (args: { current_team: string | number, deal_source: string | number } | [current_team: string | number, deal_source: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DealSourceController = { index, store, update, destroy }

export default DealSourceController