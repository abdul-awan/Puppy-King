import CrmExportController from './CrmExportController'
import CrmImportController from './CrmImportController'
import CompanyController from './CompanyController'
import CompanyContactController from './CompanyContactController'
import ContactController from './ContactController'
const Crm = {
    CrmExportController: Object.assign(CrmExportController, CrmExportController),
CrmImportController: Object.assign(CrmImportController, CrmImportController),
CompanyController: Object.assign(CompanyController, CompanyController),
CompanyContactController: Object.assign(CompanyContactController, CompanyContactController),
ContactController: Object.assign(ContactController, ContactController),
}

export default Crm