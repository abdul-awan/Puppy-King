import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/product-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::index
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:17
 * @route '/{current_team}/settings/product-categories'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::store
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:37
 * @route '/{current_team}/settings/product-categories'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/product-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::store
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:37
 * @route '/{current_team}/settings/product-categories'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::store
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:37
 * @route '/{current_team}/settings/product-categories'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::store
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:37
 * @route '/{current_team}/settings/product-categories'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::store
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:37
 * @route '/{current_team}/settings/product-categories'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
export const update = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/product-categories/{product_category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
update.url = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    product_category: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                product_category: typeof args.product_category === 'object'
                ? args.product_category.id
                : args.product_category,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{product_category}', parsedArgs.product_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
update.put = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
update.patch = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
    const updateForm = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
        updateForm.put = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::update
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:49
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
        updateForm.patch = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::destroy
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:61
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
export const destroy = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/product-categories/{product_category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::destroy
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:61
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
destroy.url = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    product_category: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                product_category: typeof args.product_category === 'object'
                ? args.product_category.id
                : args.product_category,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{product_category}', parsedArgs.product_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::destroy
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:61
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
destroy.delete = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::destroy
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:61
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
    const destroyForm = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\ProductCategoryController::destroy
 * @see app/Http/Controllers/CompanySettings/ProductCategoryController.php:61
 * @route '/{current_team}/settings/product-categories/{product_category}'
 */
        destroyForm.delete = (args: { current_team: string | number, product_category: number | { id: number } } | [current_team: string | number, product_category: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ProductCategoryController = { index, store, update, destroy }

export default ProductCategoryController