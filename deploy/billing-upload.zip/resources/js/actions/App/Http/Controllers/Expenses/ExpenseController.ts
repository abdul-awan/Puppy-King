import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
export const exportMethod = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/expenses/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
exportMethod.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
exportMethod.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
exportMethod.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
    const exportMethodForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
        exportMethodForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::exportMethod
 * @see app/Http/Controllers/Expenses/ExpenseController.php:247
 * @route '/{current_team}/expenses/export'
 */
        exportMethodForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::approve
 * @see app/Http/Controllers/Expenses/ExpenseController.php:205
 * @route '/{current_team}/expenses/{expense}/approve'
 */
export const approve = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/{current_team}/expenses/{expense}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::approve
 * @see app/Http/Controllers/Expenses/ExpenseController.php:205
 * @route '/{current_team}/expenses/{expense}/approve'
 */
approve.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return approve.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::approve
 * @see app/Http/Controllers/Expenses/ExpenseController.php:205
 * @route '/{current_team}/expenses/{expense}/approve'
 */
approve.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::approve
 * @see app/Http/Controllers/Expenses/ExpenseController.php:205
 * @route '/{current_team}/expenses/{expense}/approve'
 */
    const approveForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::approve
 * @see app/Http/Controllers/Expenses/ExpenseController.php:205
 * @route '/{current_team}/expenses/{expense}/approve'
 */
        approveForm.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::reject
 * @see app/Http/Controllers/Expenses/ExpenseController.php:224
 * @route '/{current_team}/expenses/{expense}/reject'
 */
export const reject = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/{current_team}/expenses/{expense}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::reject
 * @see app/Http/Controllers/Expenses/ExpenseController.php:224
 * @route '/{current_team}/expenses/{expense}/reject'
 */
reject.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return reject.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::reject
 * @see app/Http/Controllers/Expenses/ExpenseController.php:224
 * @route '/{current_team}/expenses/{expense}/reject'
 */
reject.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::reject
 * @see app/Http/Controllers/Expenses/ExpenseController.php:224
 * @route '/{current_team}/expenses/{expense}/reject'
 */
    const rejectForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::reject
 * @see app/Http/Controllers/Expenses/ExpenseController.php:224
 * @route '/{current_team}/expenses/{expense}/reject'
 */
        rejectForm.post = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:43
 * @route '/{current_team}/expenses'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/expenses/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::create
 * @see app/Http/Controllers/Expenses/ExpenseController.php:82
 * @route '/{current_team}/expenses/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:102
 * @route '/{current_team}/expenses'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:102
 * @route '/{current_team}/expenses'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:102
 * @route '/{current_team}/expenses'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:102
 * @route '/{current_team}/expenses'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:102
 * @route '/{current_team}/expenses'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
export const show = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/expenses/{expense}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
show.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
show.get = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
show.head = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
    const showForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
        showForm.get = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::show
 * @see app/Http/Controllers/Expenses/ExpenseController.php:133
 * @route '/{current_team}/expenses/{expense}'
 */
        showForm.head = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
export const edit = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/expenses/{expense}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
edit.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
edit.get = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
edit.head = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
    const editForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
        editForm.get = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::edit
 * @see app/Http/Controllers/Expenses/ExpenseController.php:148
 * @route '/{current_team}/expenses/{expense}/edit'
 */
        editForm.head = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
export const update = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/expenses/{expense}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
update.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
update.put = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
update.patch = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
    const updateForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
        updateForm.put = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:163
 * @route '/{current_team}/expenses/{expense}'
 */
        updateForm.patch = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:191
 * @route '/{current_team}/expenses/{expense}'
 */
export const destroy = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/expenses/{expense}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:191
 * @route '/{current_team}/expenses/{expense}'
 */
destroy.url = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:191
 * @route '/{current_team}/expenses/{expense}'
 */
destroy.delete = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:191
 * @route '/{current_team}/expenses/{expense}'
 */
    const destroyForm = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:191
 * @route '/{current_team}/expenses/{expense}'
 */
        destroyForm.delete = (args: { current_team: string | number, expense: number | { id: number } } | [current_team: string | number, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ExpenseController = { exportMethod, approve, reject, index, create, store, show, edit, update, destroy, export: exportMethod }

export default ExpenseController