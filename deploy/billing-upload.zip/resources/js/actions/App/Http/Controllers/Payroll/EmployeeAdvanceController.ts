import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::store
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:26
 * @route '/{current_team}/employees/{employee}/advances'
 */
export const store = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/employees/{employee}/advances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::store
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:26
 * @route '/{current_team}/employees/{employee}/advances'
 */
store.url = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    employee: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::store
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:26
 * @route '/{current_team}/employees/{employee}/advances'
 */
store.post = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::store
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:26
 * @route '/{current_team}/employees/{employee}/advances'
 */
    const storeForm = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::store
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:26
 * @route '/{current_team}/employees/{employee}/advances'
 */
        storeForm.post = (args: { current_team: string | number, employee: number | { id: number } } | [current_team: string | number, employee: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::update
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:44
 * @route '/{current_team}/advances/{advance}'
 */
export const update = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/advances/{advance}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::update
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:44
 * @route '/{current_team}/advances/{advance}'
 */
update.url = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    advance: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                advance: typeof args.advance === 'object'
                ? args.advance.id
                : args.advance,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{advance}', parsedArgs.advance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::update
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:44
 * @route '/{current_team}/advances/{advance}'
 */
update.put = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::update
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:44
 * @route '/{current_team}/advances/{advance}'
 */
    const updateForm = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::update
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:44
 * @route '/{current_team}/advances/{advance}'
 */
        updateForm.put = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:62
 * @route '/{current_team}/advances/{advance}'
 */
export const destroy = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/advances/{advance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:62
 * @route '/{current_team}/advances/{advance}'
 */
destroy.url = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    advance: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                advance: typeof args.advance === 'object'
                ? args.advance.id
                : args.advance,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{advance}', parsedArgs.advance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:62
 * @route '/{current_team}/advances/{advance}'
 */
destroy.delete = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:62
 * @route '/{current_team}/advances/{advance}'
 */
    const destroyForm = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\EmployeeAdvanceController::destroy
 * @see app/Http/Controllers/Payroll/EmployeeAdvanceController.php:62
 * @route '/{current_team}/advances/{advance}'
 */
        destroyForm.delete = (args: { current_team: string | number, advance: number | { id: number } } | [current_team: string | number, advance: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const EmployeeAdvanceController = { store, update, destroy }

export default EmployeeAdvanceController