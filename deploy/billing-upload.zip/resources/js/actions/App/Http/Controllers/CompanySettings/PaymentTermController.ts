import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/payment-terms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::index
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:18
 * @route '/{current_team}/settings/payment-terms'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::store
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:31
 * @route '/{current_team}/settings/payment-terms'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/payment-terms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::store
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:31
 * @route '/{current_team}/settings/payment-terms'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::store
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:31
 * @route '/{current_team}/settings/payment-terms'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::store
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:31
 * @route '/{current_team}/settings/payment-terms'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::store
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:31
 * @route '/{current_team}/settings/payment-terms'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
export const update = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/payment-terms/{payment_term}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
update.url = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payment_term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payment_term: typeof args.payment_term === 'object'
                ? args.payment_term.id
                : args.payment_term,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payment_term}', parsedArgs.payment_term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
update.put = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
update.patch = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
    const updateForm = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
        updateForm.put = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::update
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:48
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
        updateForm.patch = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::destroy
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:65
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
export const destroy = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/payment-terms/{payment_term}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::destroy
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:65
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
destroy.url = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payment_term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payment_term: typeof args.payment_term === 'object'
                ? args.payment_term.id
                : args.payment_term,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payment_term}', parsedArgs.payment_term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::destroy
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:65
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
destroy.delete = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::destroy
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:65
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
    const destroyForm = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PaymentTermController::destroy
 * @see app/Http/Controllers/CompanySettings/PaymentTermController.php:65
 * @route '/{current_team}/settings/payment-terms/{payment_term}'
 */
        destroyForm.delete = (args: { current_team: string | number, payment_term: number | { id: number } } | [current_team: string | number, payment_term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PaymentTermController = { index, store, update, destroy }

export default PaymentTermController