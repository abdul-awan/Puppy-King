import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Projects\MilestoneController::store
 * @see app/Http/Controllers/Projects/MilestoneController.php:16
 * @route '/{current_team}/projects/{project}/milestones'
 */
export const store = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/projects/{project}/milestones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Projects\MilestoneController::store
 * @see app/Http/Controllers/Projects/MilestoneController.php:16
 * @route '/{current_team}/projects/{project}/milestones'
 */
store.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\MilestoneController::store
 * @see app/Http/Controllers/Projects/MilestoneController.php:16
 * @route '/{current_team}/projects/{project}/milestones'
 */
store.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Projects\MilestoneController::store
 * @see app/Http/Controllers/Projects/MilestoneController.php:16
 * @route '/{current_team}/projects/{project}/milestones'
 */
    const storeForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\MilestoneController::store
 * @see app/Http/Controllers/Projects/MilestoneController.php:16
 * @route '/{current_team}/projects/{project}/milestones'
 */
        storeForm.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Projects\MilestoneController::update
 * @see app/Http/Controllers/Projects/MilestoneController.php:29
 * @route '/{current_team}/milestones/{milestone}'
 */
export const update = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/milestones/{milestone}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Projects\MilestoneController::update
 * @see app/Http/Controllers/Projects/MilestoneController.php:29
 * @route '/{current_team}/milestones/{milestone}'
 */
update.url = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\MilestoneController::update
 * @see app/Http/Controllers/Projects/MilestoneController.php:29
 * @route '/{current_team}/milestones/{milestone}'
 */
update.put = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Projects\MilestoneController::update
 * @see app/Http/Controllers/Projects/MilestoneController.php:29
 * @route '/{current_team}/milestones/{milestone}'
 */
    const updateForm = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\MilestoneController::update
 * @see app/Http/Controllers/Projects/MilestoneController.php:29
 * @route '/{current_team}/milestones/{milestone}'
 */
        updateForm.put = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Projects\MilestoneController::destroy
 * @see app/Http/Controllers/Projects/MilestoneController.php:39
 * @route '/{current_team}/milestones/{milestone}'
 */
export const destroy = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/milestones/{milestone}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Projects\MilestoneController::destroy
 * @see app/Http/Controllers/Projects/MilestoneController.php:39
 * @route '/{current_team}/milestones/{milestone}'
 */
destroy.url = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\MilestoneController::destroy
 * @see app/Http/Controllers/Projects/MilestoneController.php:39
 * @route '/{current_team}/milestones/{milestone}'
 */
destroy.delete = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Projects\MilestoneController::destroy
 * @see app/Http/Controllers/Projects/MilestoneController.php:39
 * @route '/{current_team}/milestones/{milestone}'
 */
    const destroyForm = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\MilestoneController::destroy
 * @see app/Http/Controllers/Projects/MilestoneController.php:39
 * @route '/{current_team}/milestones/{milestone}'
 */
        destroyForm.delete = (args: { current_team: string | number, milestone: number | { id: number } } | [current_team: string | number, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const MilestoneController = { store, update, destroy }

export default MilestoneController