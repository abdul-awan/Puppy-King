import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
export const show = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/p/q/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
show.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return show.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
show.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
show.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
    const showForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
        showForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::show
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:31
 * @route '/p/q/{token}'
 */
        showForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
export const pdf = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/p/q/{token}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
pdf.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return pdf.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
pdf.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
pdf.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
    const pdfForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
        pdfForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::pdf
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:56
 * @route '/p/q/{token}/pdf'
 */
        pdfForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::accept
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:69
 * @route '/p/q/{token}/accept'
 */
export const accept = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

accept.definition = {
    methods: ["post"],
    url: '/p/q/{token}/accept',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::accept
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:69
 * @route '/p/q/{token}/accept'
 */
accept.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return accept.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::accept
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:69
 * @route '/p/q/{token}/accept'
 */
accept.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::accept
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:69
 * @route '/p/q/{token}/accept'
 */
    const acceptForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::accept
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:69
 * @route '/p/q/{token}/accept'
 */
        acceptForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(args, options),
            method: 'post',
        })
    
    accept.form = acceptForm
/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::decline
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:93
 * @route '/p/q/{token}/decline'
 */
export const decline = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decline.url(args, options),
    method: 'post',
})

decline.definition = {
    methods: ["post"],
    url: '/p/q/{token}/decline',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::decline
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:93
 * @route '/p/q/{token}/decline'
 */
decline.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return decline.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Portal\QuotationPortalController::decline
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:93
 * @route '/p/q/{token}/decline'
 */
decline.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decline.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::decline
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:93
 * @route '/p/q/{token}/decline'
 */
    const declineForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: decline.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Portal\QuotationPortalController::decline
 * @see app/Http/Controllers/Portal/QuotationPortalController.php:93
 * @route '/p/q/{token}/decline'
 */
        declineForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: decline.url(args, options),
            method: 'post',
        })
    
    decline.form = declineForm
const QuotationPortalController = { show, pdf, accept, decline }

export default QuotationPortalController