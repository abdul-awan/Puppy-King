import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
export const companies = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(args, options),
    method: 'get',
})

companies.definition = {
    methods: ["get","head"],
    url: '/{current_team}/companies/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
companies.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return companies.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
companies.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
companies.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companies.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
    const companiesForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companies.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
        companiesForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CrmExportController::companies
 * @see app/Http/Controllers/Crm/CrmExportController.php:17
 * @route '/{current_team}/companies/export'
 */
        companiesForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companies.form = companiesForm
/**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
export const contacts = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contacts.url(args, options),
    method: 'get',
})

contacts.definition = {
    methods: ["get","head"],
    url: '/{current_team}/contacts/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
contacts.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return contacts.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
contacts.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contacts.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
contacts.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contacts.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
    const contactsForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contacts.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
        contactsForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contacts.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CrmExportController::contacts
 * @see app/Http/Controllers/Crm/CrmExportController.php:64
 * @route '/{current_team}/contacts/export'
 */
        contactsForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contacts.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contacts.form = contactsForm
const CrmExportController = { companies, contacts }

export default CrmExportController