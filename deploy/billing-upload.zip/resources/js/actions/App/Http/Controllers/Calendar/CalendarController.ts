import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Calendar\CalendarController::index
 * @see app/Http/Controllers/Calendar/CalendarController.php:38
 * @route '/{current_team}/calendar'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Calendar\CalendarController::store
 * @see app/Http/Controllers/Calendar/CalendarController.php:96
 * @route '/{current_team}/calendar'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/calendar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::store
 * @see app/Http/Controllers/Calendar/CalendarController.php:96
 * @route '/{current_team}/calendar'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::store
 * @see app/Http/Controllers/Calendar/CalendarController.php:96
 * @route '/{current_team}/calendar'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::store
 * @see app/Http/Controllers/Calendar/CalendarController.php:96
 * @route '/{current_team}/calendar'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::store
 * @see app/Http/Controllers/Calendar/CalendarController.php:96
 * @route '/{current_team}/calendar'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Calendar\CalendarController::update
 * @see app/Http/Controllers/Calendar/CalendarController.php:117
 * @route '/{current_team}/calendar/{event}'
 */
export const update = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/calendar/{event}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::update
 * @see app/Http/Controllers/Calendar/CalendarController.php:117
 * @route '/{current_team}/calendar/{event}'
 */
update.url = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::update
 * @see app/Http/Controllers/Calendar/CalendarController.php:117
 * @route '/{current_team}/calendar/{event}'
 */
update.put = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::update
 * @see app/Http/Controllers/Calendar/CalendarController.php:117
 * @route '/{current_team}/calendar/{event}'
 */
    const updateForm = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::update
 * @see app/Http/Controllers/Calendar/CalendarController.php:117
 * @route '/{current_team}/calendar/{event}'
 */
        updateForm.put = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Calendar\CalendarController::complete
 * @see app/Http/Controllers/Calendar/CalendarController.php:138
 * @route '/{current_team}/calendar/{event}/complete'
 */
export const complete = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/{current_team}/calendar/{event}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::complete
 * @see app/Http/Controllers/Calendar/CalendarController.php:138
 * @route '/{current_team}/calendar/{event}/complete'
 */
complete.url = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return complete.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::complete
 * @see app/Http/Controllers/Calendar/CalendarController.php:138
 * @route '/{current_team}/calendar/{event}/complete'
 */
complete.post = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::complete
 * @see app/Http/Controllers/Calendar/CalendarController.php:138
 * @route '/{current_team}/calendar/{event}/complete'
 */
    const completeForm = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::complete
 * @see app/Http/Controllers/Calendar/CalendarController.php:138
 * @route '/{current_team}/calendar/{event}/complete'
 */
        completeForm.post = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\Calendar\CalendarController::destroy
 * @see app/Http/Controllers/Calendar/CalendarController.php:150
 * @route '/{current_team}/calendar/{event}'
 */
export const destroy = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/calendar/{event}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::destroy
 * @see app/Http/Controllers/Calendar/CalendarController.php:150
 * @route '/{current_team}/calendar/{event}'
 */
destroy.url = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::destroy
 * @see app/Http/Controllers/Calendar/CalendarController.php:150
 * @route '/{current_team}/calendar/{event}'
 */
destroy.delete = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::destroy
 * @see app/Http/Controllers/Calendar/CalendarController.php:150
 * @route '/{current_team}/calendar/{event}'
 */
    const destroyForm = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::destroy
 * @see app/Http/Controllers/Calendar/CalendarController.php:150
 * @route '/{current_team}/calendar/{event}'
 */
        destroyForm.delete = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
export const ics = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ics.url(args, options),
    method: 'get',
})

ics.definition = {
    methods: ["get","head"],
    url: '/{current_team}/calendar/{event}/ics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
ics.url = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return ics.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
ics.get = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
ics.head = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
    const icsForm = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
        icsForm.get = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Calendar\CalendarController::ics
 * @see app/Http/Controllers/Calendar/CalendarController.php:160
 * @route '/{current_team}/calendar/{event}/ics'
 */
        icsForm.head = (args: { current_team: string | number, event: number | { id: number } } | [current_team: string | number, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ics.form = icsForm
const CalendarController = { index, store, update, complete, destroy, ics }

export default CalendarController