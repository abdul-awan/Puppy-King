import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::store
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:24
 * @route '/{current_team}/settings/pay-components'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/pay-components',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::store
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:24
 * @route '/{current_team}/settings/pay-components'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::store
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:24
 * @route '/{current_team}/settings/pay-components'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::store
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:24
 * @route '/{current_team}/settings/pay-components'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::store
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:24
 * @route '/{current_team}/settings/pay-components'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
export const update = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/pay-components/{pay_component}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
update.url = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pay_component: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pay_component: typeof args.pay_component === 'object'
                ? args.pay_component.id
                : args.pay_component,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pay_component}', parsedArgs.pay_component.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
update.put = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
update.patch = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
    const updateForm = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
        updateForm.put = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::update
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:36
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
        updateForm.patch = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::destroy
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:48
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
export const destroy = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/pay-components/{pay_component}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::destroy
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:48
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
destroy.url = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    pay_component: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                pay_component: typeof args.pay_component === 'object'
                ? args.pay_component.id
                : args.pay_component,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{pay_component}', parsedArgs.pay_component.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::destroy
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:48
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
destroy.delete = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::destroy
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:48
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
    const destroyForm = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PayComponentController::destroy
 * @see app/Http/Controllers/CompanySettings/PayComponentController.php:48
 * @route '/{current_team}/settings/pay-components/{pay_component}'
 */
        destroyForm.delete = (args: { current_team: string | number, pay_component: number | { id: number } } | [current_team: string | number, pay_component: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PayComponentController = { store, update, destroy }

export default PayComponentController