import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::store
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:23
 * @route '/{current_team}/settings/invoice-settings/template-images'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/invoice-settings/template-images',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::store
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:23
 * @route '/{current_team}/settings/invoice-settings/template-images'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::store
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:23
 * @route '/{current_team}/settings/invoice-settings/template-images'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::store
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:23
 * @route '/{current_team}/settings/invoice-settings/template-images'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::store
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:23
 * @route '/{current_team}/settings/invoice-settings/template-images'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
export const show = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/invoice-settings/template-images/{name}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
show.url = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    name: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                name: args.name,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{name}', parsedArgs.name.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
show.get = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
show.head = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
    const showForm = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
        showForm.get = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\TemplateImageController::show
 * @see app/Http/Controllers/CompanySettings/TemplateImageController.php:52
 * @route '/{current_team}/settings/invoice-settings/template-images/{name}'
 */
        showForm.head = (args: { current_team: string | number, name: string | number } | [current_team: string | number, name: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const TemplateImageController = { store, show }

export default TemplateImageController