import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::index
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:56
 * @route '/{current_team}/payroll'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::store
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:93
 * @route '/{current_team}/payroll'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::store
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:93
 * @route '/{current_team}/payroll'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::store
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:93
 * @route '/{current_team}/payroll'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::store
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:93
 * @route '/{current_team}/payroll'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::store
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:93
 * @route '/{current_team}/payroll'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
export const show = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payroll/{payroll_run}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
show.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
show.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
show.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
    const showForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
        showForm.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::show
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:130
 * @route '/{current_team}/payroll/{payroll_run}'
 */
        showForm.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::update
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:165
 * @route '/{current_team}/payroll/{payroll_run}'
 */
export const update = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/{current_team}/payroll/{payroll_run}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::update
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:165
 * @route '/{current_team}/payroll/{payroll_run}'
 */
update.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::update
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:165
 * @route '/{current_team}/payroll/{payroll_run}'
 */
update.patch = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::update
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:165
 * @route '/{current_team}/payroll/{payroll_run}'
 */
    const updateForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::update
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:165
 * @route '/{current_team}/payroll/{payroll_run}'
 */
        updateForm.patch = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::destroy
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:182
 * @route '/{current_team}/payroll/{payroll_run}'
 */
export const destroy = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/payroll/{payroll_run}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::destroy
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:182
 * @route '/{current_team}/payroll/{payroll_run}'
 */
destroy.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::destroy
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:182
 * @route '/{current_team}/payroll/{payroll_run}'
 */
destroy.delete = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::destroy
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:182
 * @route '/{current_team}/payroll/{payroll_run}'
 */
    const destroyForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::destroy
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:182
 * @route '/{current_team}/payroll/{payroll_run}'
 */
        destroyForm.delete = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::recalculate
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:197
 * @route '/{current_team}/payroll/{payroll_run}/recalculate'
 */
export const recalculate = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::recalculate
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:197
 * @route '/{current_team}/payroll/{payroll_run}/recalculate'
 */
recalculate.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return recalculate.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::recalculate
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:197
 * @route '/{current_team}/payroll/{payroll_run}/recalculate'
 */
recalculate.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::recalculate
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:197
 * @route '/{current_team}/payroll/{payroll_run}/recalculate'
 */
    const recalculateForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::recalculate
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:197
 * @route '/{current_team}/payroll/{payroll_run}/recalculate'
 */
        recalculateForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(args, options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::addEmployee
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:218
 * @route '/{current_team}/payroll/{payroll_run}/employees'
 */
export const addEmployee = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addEmployee.url(args, options),
    method: 'post',
})

addEmployee.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/employees',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::addEmployee
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:218
 * @route '/{current_team}/payroll/{payroll_run}/employees'
 */
addEmployee.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return addEmployee.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::addEmployee
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:218
 * @route '/{current_team}/payroll/{payroll_run}/employees'
 */
addEmployee.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addEmployee.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::addEmployee
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:218
 * @route '/{current_team}/payroll/{payroll_run}/employees'
 */
    const addEmployeeForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addEmployee.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::addEmployee
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:218
 * @route '/{current_team}/payroll/{payroll_run}/employees'
 */
        addEmployeeForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addEmployee.url(args, options),
            method: 'post',
        })
    
    addEmployee.form = addEmployeeForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::approve
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:246
 * @route '/{current_team}/payroll/{payroll_run}/approve'
 */
export const approve = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::approve
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:246
 * @route '/{current_team}/payroll/{payroll_run}/approve'
 */
approve.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return approve.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::approve
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:246
 * @route '/{current_team}/payroll/{payroll_run}/approve'
 */
approve.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::approve
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:246
 * @route '/{current_team}/payroll/{payroll_run}/approve'
 */
    const approveForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::approve
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:246
 * @route '/{current_team}/payroll/{payroll_run}/approve'
 */
        approveForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::reopen
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:292
 * @route '/{current_team}/payroll/{payroll_run}/reopen'
 */
export const reopen = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

reopen.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/reopen',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::reopen
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:292
 * @route '/{current_team}/payroll/{payroll_run}/reopen'
 */
reopen.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return reopen.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::reopen
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:292
 * @route '/{current_team}/payroll/{payroll_run}/reopen'
 */
reopen.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::reopen
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:292
 * @route '/{current_team}/payroll/{payroll_run}/reopen'
 */
    const reopenForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reopen.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::reopen
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:292
 * @route '/{current_team}/payroll/{payroll_run}/reopen'
 */
        reopenForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reopen.url(args, options),
            method: 'post',
        })
    
    reopen.form = reopenForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:309
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
export const pay = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:309
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
pay.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return pay.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:309
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
pay.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:309
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
    const payForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pay.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:309
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
        payForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pay.url(args, options),
            method: 'post',
        })
    
    pay.form = payForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::unpay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:339
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
export const unpay = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unpay.url(args, options),
    method: 'delete',
})

unpay.definition = {
    methods: ["delete"],
    url: '/{current_team}/payroll/{payroll_run}/pay',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::unpay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:339
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
unpay.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return unpay.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::unpay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:339
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
unpay.delete = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unpay.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::unpay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:339
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
    const unpayForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unpay.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::unpay
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:339
 * @route '/{current_team}/payroll/{payroll_run}/pay'
 */
        unpayForm.delete = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unpay.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unpay.form = unpayForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::email
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:359
 * @route '/{current_team}/payroll/{payroll_run}/email'
 */
export const email = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(args, options),
    method: 'post',
})

email.definition = {
    methods: ["post"],
    url: '/{current_team}/payroll/{payroll_run}/email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::email
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:359
 * @route '/{current_team}/payroll/{payroll_run}/email'
 */
email.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return email.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::email
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:359
 * @route '/{current_team}/payroll/{payroll_run}/email'
 */
email.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::email
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:359
 * @route '/{current_team}/payroll/{payroll_run}/email'
 */
    const emailForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: email.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::email
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:359
 * @route '/{current_team}/payroll/{payroll_run}/email'
 */
        emailForm.post = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: email.url(args, options),
            method: 'post',
        })
    
    email.form = emailForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
export const pdf = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payroll/{payroll_run}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
pdf.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
pdf.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
pdf.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::pdf
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:415
 * @route '/{current_team}/payroll/{payroll_run}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
export const register = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(args, options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payroll/{payroll_run}/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
register.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return register.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
register.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
register.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
    const registerForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
        registerForm.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::register
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:435
 * @route '/{current_team}/payroll/{payroll_run}/register'
 */
        registerForm.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
export const bankTransfers = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankTransfers.url(args, options),
    method: 'get',
})

bankTransfers.definition = {
    methods: ["get","head"],
    url: '/{current_team}/payroll/{payroll_run}/bank-transfers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
bankTransfers.url = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    payroll_run: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                payroll_run: typeof args.payroll_run === 'object'
                ? args.payroll_run.id
                : args.payroll_run,
                }

    return bankTransfers.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{payroll_run}', parsedArgs.payroll_run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
bankTransfers.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankTransfers.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
bankTransfers.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bankTransfers.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
    const bankTransfersForm = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bankTransfers.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
        bankTransfersForm.get = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankTransfers.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\PayrollRunController::bankTransfers
 * @see app/Http/Controllers/Payroll/PayrollRunController.php:483
 * @route '/{current_team}/payroll/{payroll_run}/bank-transfers'
 */
        bankTransfersForm.head = (args: { current_team: string | number, payroll_run: number | { id: number } } | [current_team: string | number, payroll_run: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankTransfers.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bankTransfers.form = bankTransfersForm
const PayrollRunController = { index, store, show, update, destroy, recalculate, addEmployee, approve, reopen, pay, unpay, email, pdf, register, bankTransfers }

export default PayrollRunController