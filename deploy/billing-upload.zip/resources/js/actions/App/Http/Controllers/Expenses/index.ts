import ExpenseController from './ExpenseController'
import ExpensePaymentController from './ExpensePaymentController'
const Expenses = {
    ExpenseController: Object.assign(ExpenseController, ExpenseController),
ExpensePaymentController: Object.assign(ExpensePaymentController, ExpensePaymentController),
}

export default Expenses