import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses/cash-book',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::index
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:28
 * @route '/{current_team}/daily-expenses/cash-book'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
export const exportMethod = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses/cash-book/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
exportMethod.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
exportMethod.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
exportMethod.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
    const exportMethodForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
        exportMethodForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:96
 * @route '/{current_team}/daily-expenses/cash-book/export'
 */
        exportMethodForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::store
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:60
 * @route '/{current_team}/daily-expenses/cash-book'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/daily-expenses/cash-book',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::store
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:60
 * @route '/{current_team}/daily-expenses/cash-book'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::store
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:60
 * @route '/{current_team}/daily-expenses/cash-book'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::store
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:60
 * @route '/{current_team}/daily-expenses/cash-book'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::store
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:60
 * @route '/{current_team}/daily-expenses/cash-book'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::update
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:72
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
export const update = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::update
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:72
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
update.url = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    petty_cash_entry: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                petty_cash_entry: typeof args.petty_cash_entry === 'object'
                ? args.petty_cash_entry.id
                : args.petty_cash_entry,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{petty_cash_entry}', parsedArgs.petty_cash_entry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::update
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:72
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
update.put = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::update
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:72
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
    const updateForm = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::update
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:72
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
        updateForm.put = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::destroy
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:84
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
export const destroy = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::destroy
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:84
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
destroy.url = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    petty_cash_entry: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                petty_cash_entry: typeof args.petty_cash_entry === 'object'
                ? args.petty_cash_entry.id
                : args.petty_cash_entry,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{petty_cash_entry}', parsedArgs.petty_cash_entry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::destroy
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:84
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
destroy.delete = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::destroy
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:84
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
    const destroyForm = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\PettyCashController::destroy
 * @see app/Http/Controllers/DailyExpenses/PettyCashController.php:84
 * @route '/{current_team}/daily-expenses/cash-book/{petty_cash_entry}'
 */
        destroyForm.delete = (args: { current_team: string | number, petty_cash_entry: number | { id: number } } | [current_team: string | number, petty_cash_entry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PettyCashController = { index, exportMethod, store, update, destroy, export: exportMethod }

export default PettyCashController