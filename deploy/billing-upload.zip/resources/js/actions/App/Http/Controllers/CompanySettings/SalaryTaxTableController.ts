import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::store
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:21
 * @route '/{current_team}/settings/salary-tax-tables'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/salary-tax-tables',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::store
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:21
 * @route '/{current_team}/settings/salary-tax-tables'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::store
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:21
 * @route '/{current_team}/settings/salary-tax-tables'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::store
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:21
 * @route '/{current_team}/settings/salary-tax-tables'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::store
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:21
 * @route '/{current_team}/settings/salary-tax-tables'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
export const update = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/salary-tax-tables/{salary_tax_table}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
update.url = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    salary_tax_table: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                salary_tax_table: typeof args.salary_tax_table === 'object'
                ? args.salary_tax_table.id
                : args.salary_tax_table,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{salary_tax_table}', parsedArgs.salary_tax_table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
update.put = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
update.patch = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
    const updateForm = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
        updateForm.put = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::update
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:33
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
        updateForm.patch = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::destroy
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:45
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
export const destroy = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/salary-tax-tables/{salary_tax_table}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::destroy
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:45
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
destroy.url = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    salary_tax_table: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                salary_tax_table: typeof args.salary_tax_table === 'object'
                ? args.salary_tax_table.id
                : args.salary_tax_table,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{salary_tax_table}', parsedArgs.salary_tax_table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::destroy
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:45
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
destroy.delete = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::destroy
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:45
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
    const destroyForm = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\SalaryTaxTableController::destroy
 * @see app/Http/Controllers/CompanySettings/SalaryTaxTableController.php:45
 * @route '/{current_team}/settings/salary-tax-tables/{salary_tax_table}'
 */
        destroyForm.delete = (args: { current_team: string | number, salary_tax_table: number | { id: number } } | [current_team: string | number, salary_tax_table: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SalaryTaxTableController = { store, update, destroy }

export default SalaryTaxTableController