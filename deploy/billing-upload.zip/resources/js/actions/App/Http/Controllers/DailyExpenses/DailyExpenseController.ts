import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
export const exportMethod = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
exportMethod.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
exportMethod.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
exportMethod.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
    const exportMethodForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
        exportMethodForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::exportMethod
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:158
 * @route '/{current_team}/daily-expenses/export'
 */
        exportMethodForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
export const pdf = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
pdf.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
pdf.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
pdf.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
    const pdfForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
        pdfForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::pdf
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:200
 * @route '/{current_team}/daily-expenses/print'
 */
        pdfForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::index
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:41
 * @route '/{current_team}/daily-expenses'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::store
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:93
 * @route '/{current_team}/daily-expenses'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/daily-expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::store
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:93
 * @route '/{current_team}/daily-expenses'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::store
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:93
 * @route '/{current_team}/daily-expenses'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::store
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:93
 * @route '/{current_team}/daily-expenses'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::store
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:93
 * @route '/{current_team}/daily-expenses'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
export const show = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/daily-expenses/{daily_expense}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
show.url = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    daily_expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                daily_expense: typeof args.daily_expense === 'object'
                ? args.daily_expense.id
                : args.daily_expense,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{daily_expense}', parsedArgs.daily_expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
show.get = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
show.head = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
    const showForm = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
        showForm.get = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::show
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:116
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
        showForm.head = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
export const update = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/daily-expenses/{daily_expense}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
update.url = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    daily_expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                daily_expense: typeof args.daily_expense === 'object'
                ? args.daily_expense.id
                : args.daily_expense,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{daily_expense}', parsedArgs.daily_expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
update.put = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
update.patch = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
    const updateForm = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
        updateForm.put = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::update
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:131
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
        updateForm.patch = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::destroy
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:145
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
export const destroy = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/daily-expenses/{daily_expense}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::destroy
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:145
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
destroy.url = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    daily_expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                daily_expense: typeof args.daily_expense === 'object'
                ? args.daily_expense.id
                : args.daily_expense,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{daily_expense}', parsedArgs.daily_expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::destroy
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:145
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
destroy.delete = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::destroy
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:145
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
    const destroyForm = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DailyExpenses\DailyExpenseController::destroy
 * @see app/Http/Controllers/DailyExpenses/DailyExpenseController.php:145
 * @route '/{current_team}/daily-expenses/{daily_expense}'
 */
        destroyForm.delete = (args: { current_team: string | number, daily_expense: number | { id: number } } | [current_team: string | number, daily_expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DailyExpenseController = { exportMethod, pdf, index, store, show, update, destroy, export: exportMethod }

export default DailyExpenseController