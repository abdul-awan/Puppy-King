import GeneralSettingsController from './GeneralSettingsController'
import DepartmentController from './DepartmentController'
import TaxRateController from './TaxRateController'
import PaymentTermController from './PaymentTermController'
import WorkTypeController from './WorkTypeController'
import TagController from './TagController'
import CustomFieldController from './CustomFieldController'
import ProductCategoryController from './ProductCategoryController'
import DealSourceController from './DealSourceController'
import LostReasonController from './LostReasonController'
import ExpenseCategoryController from './ExpenseCategoryController'
import DailyExpenseCategoryController from './DailyExpenseCategoryController'
import PayrollSettingsController from './PayrollSettingsController'
import PayComponentController from './PayComponentController'
import SalaryTaxTableController from './SalaryTaxTableController'
import PipelineController from './PipelineController'
import NumberingController from './NumberingController'
import InvoiceSettingsController from './InvoiceSettingsController'
import DocumentTemplateController from './DocumentTemplateController'
import TemplateImageController from './TemplateImageController'
import EmailTemplateController from './EmailTemplateController'
import MemberAccessController from './MemberAccessController'
const CompanySettings = {
    GeneralSettingsController: Object.assign(GeneralSettingsController, GeneralSettingsController),
DepartmentController: Object.assign(DepartmentController, DepartmentController),
TaxRateController: Object.assign(TaxRateController, TaxRateController),
PaymentTermController: Object.assign(PaymentTermController, PaymentTermController),
WorkTypeController: Object.assign(WorkTypeController, WorkTypeController),
TagController: Object.assign(TagController, TagController),
CustomFieldController: Object.assign(CustomFieldController, CustomFieldController),
ProductCategoryController: Object.assign(ProductCategoryController, ProductCategoryController),
DealSourceController: Object.assign(DealSourceController, DealSourceController),
LostReasonController: Object.assign(LostReasonController, LostReasonController),
ExpenseCategoryController: Object.assign(ExpenseCategoryController, ExpenseCategoryController),
DailyExpenseCategoryController: Object.assign(DailyExpenseCategoryController, DailyExpenseCategoryController),
PayrollSettingsController: Object.assign(PayrollSettingsController, PayrollSettingsController),
PayComponentController: Object.assign(PayComponentController, PayComponentController),
SalaryTaxTableController: Object.assign(SalaryTaxTableController, SalaryTaxTableController),
PipelineController: Object.assign(PipelineController, PipelineController),
NumberingController: Object.assign(NumberingController, NumberingController),
InvoiceSettingsController: Object.assign(InvoiceSettingsController, InvoiceSettingsController),
DocumentTemplateController: Object.assign(DocumentTemplateController, DocumentTemplateController),
TemplateImageController: Object.assign(TemplateImageController, TemplateImageController),
EmailTemplateController: Object.assign(EmailTemplateController, EmailTemplateController),
MemberAccessController: Object.assign(MemberAccessController, MemberAccessController),
}

export default CompanySettings