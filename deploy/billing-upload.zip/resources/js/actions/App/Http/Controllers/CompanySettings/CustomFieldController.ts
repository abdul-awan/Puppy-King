import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/custom-fields',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::index
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:24
 * @route '/{current_team}/settings/custom-fields'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::store
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:38
 * @route '/{current_team}/settings/custom-fields'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/custom-fields',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::store
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:38
 * @route '/{current_team}/settings/custom-fields'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::store
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:38
 * @route '/{current_team}/settings/custom-fields'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::store
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:38
 * @route '/{current_team}/settings/custom-fields'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::store
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:38
 * @route '/{current_team}/settings/custom-fields'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
export const update = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/custom-fields/{custom_field}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
update.url = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    custom_field: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                custom_field: typeof args.custom_field === 'object'
                ? args.custom_field.id
                : args.custom_field,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{custom_field}', parsedArgs.custom_field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
update.put = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
update.patch = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
    const updateForm = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
        updateForm.put = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::update
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:53
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
        updateForm.patch = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::destroy
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:68
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
export const destroy = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/custom-fields/{custom_field}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::destroy
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:68
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
destroy.url = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    custom_field: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                custom_field: typeof args.custom_field === 'object'
                ? args.custom_field.id
                : args.custom_field,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{custom_field}', parsedArgs.custom_field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::destroy
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:68
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
destroy.delete = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::destroy
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:68
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
    const destroyForm = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\CustomFieldController::destroy
 * @see app/Http/Controllers/CompanySettings/CustomFieldController.php:68
 * @route '/{current_team}/settings/custom-fields/{custom_field}'
 */
        destroyForm.delete = (args: { current_team: string | number, custom_field: number | { id: number } } | [current_team: string | number, custom_field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CustomFieldController = { index, store, update, destroy }

export default CustomFieldController