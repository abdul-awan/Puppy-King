import QuotationPortalController from './QuotationPortalController'
import DocumentPortalController from './DocumentPortalController'
import WorkOrderPortalController from './WorkOrderPortalController'
import TicketPortalController from './TicketPortalController'
const Portal = {
    QuotationPortalController: Object.assign(QuotationPortalController, QuotationPortalController),
DocumentPortalController: Object.assign(DocumentPortalController, DocumentPortalController),
WorkOrderPortalController: Object.assign(WorkOrderPortalController, WorkOrderPortalController),
TicketPortalController: Object.assign(TicketPortalController, TicketPortalController),
}

export default Portal