import QuotationController from './QuotationController'
const Documents = {
    QuotationController: Object.assign(QuotationController, QuotationController),
}

export default Documents