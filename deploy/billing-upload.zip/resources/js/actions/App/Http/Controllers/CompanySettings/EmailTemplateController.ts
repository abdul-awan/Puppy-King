import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/email-templates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::index
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:17
 * @route '/{current_team}/settings/email-templates'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::update
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:38
 * @route '/{current_team}/settings/email-templates/{emailTemplate}'
 */
export const update = (args: { current_team: string | number, emailTemplate: number | { id: number } } | [current_team: string | number, emailTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/email-templates/{emailTemplate}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::update
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:38
 * @route '/{current_team}/settings/email-templates/{emailTemplate}'
 */
update.url = (args: { current_team: string | number, emailTemplate: number | { id: number } } | [current_team: string | number, emailTemplate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    emailTemplate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                emailTemplate: typeof args.emailTemplate === 'object'
                ? args.emailTemplate.id
                : args.emailTemplate,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{emailTemplate}', parsedArgs.emailTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::update
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:38
 * @route '/{current_team}/settings/email-templates/{emailTemplate}'
 */
update.put = (args: { current_team: string | number, emailTemplate: number | { id: number } } | [current_team: string | number, emailTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::update
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:38
 * @route '/{current_team}/settings/email-templates/{emailTemplate}'
 */
    const updateForm = (args: { current_team: string | number, emailTemplate: number | { id: number } } | [current_team: string | number, emailTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\EmailTemplateController::update
 * @see app/Http/Controllers/CompanySettings/EmailTemplateController.php:38
 * @route '/{current_team}/settings/email-templates/{emailTemplate}'
 */
        updateForm.put = (args: { current_team: string | number, emailTemplate: number | { id: number } } | [current_team: string | number, emailTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const EmailTemplateController = { index, update }

export default EmailTemplateController