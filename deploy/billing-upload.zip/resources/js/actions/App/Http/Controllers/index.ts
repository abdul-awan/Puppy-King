import Portal from './Portal'
import Admin from './Admin'
import DashboardController from './DashboardController'
import NoteController from './NoteController'
import AttachmentController from './AttachmentController'
import LookupController from './LookupController'
import SearchController from './SearchController'
import NotificationController from './NotificationController'
import Payroll from './Payroll'
import Crm from './Crm'
import DealController from './DealController'
import Documents from './Documents'
import Invoicing from './Invoicing'
import Expenses from './Expenses'
import DailyExpenses from './DailyExpenses'
import Projects from './Projects'
import Time from './Time'
import Planning from './Planning'
import Tickets from './Tickets'
import WorkOrders from './WorkOrders'
import Calendar from './Calendar'
import Reports from './Reports'
import ProductController from './ProductController'
import CompanySettings from './CompanySettings'
import Teams from './Teams'
import Settings from './Settings'
const Controllers = {
    Portal: Object.assign(Portal, Portal),
Admin: Object.assign(Admin, Admin),
DashboardController: Object.assign(DashboardController, DashboardController),
NoteController: Object.assign(NoteController, NoteController),
AttachmentController: Object.assign(AttachmentController, AttachmentController),
LookupController: Object.assign(LookupController, LookupController),
SearchController: Object.assign(SearchController, SearchController),
NotificationController: Object.assign(NotificationController, NotificationController),
Payroll: Object.assign(Payroll, Payroll),
Crm: Object.assign(Crm, Crm),
DealController: Object.assign(DealController, DealController),
Documents: Object.assign(Documents, Documents),
Invoicing: Object.assign(Invoicing, Invoicing),
Expenses: Object.assign(Expenses, Expenses),
DailyExpenses: Object.assign(DailyExpenses, DailyExpenses),
Projects: Object.assign(Projects, Projects),
Time: Object.assign(Time, Time),
Planning: Object.assign(Planning, Planning),
Tickets: Object.assign(Tickets, Tickets),
WorkOrders: Object.assign(WorkOrders, WorkOrders),
Calendar: Object.assign(Calendar, Calendar),
Reports: Object.assign(Reports, Reports),
ProductController: Object.assign(ProductController, ProductController),
CompanySettings: Object.assign(CompanySettings, CompanySettings),
Teams: Object.assign(Teams, Teams),
Settings: Object.assign(Settings, Settings),
}

export default Controllers