import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:25
 * @route '/{current_team}/attachments'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:25
 * @route '/{current_team}/attachments'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:25
 * @route '/{current_team}/attachments'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:25
 * @route '/{current_team}/attachments'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:25
 * @route '/{current_team}/attachments'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
export const show = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/attachments/{attachment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
show.url = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
show.get = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
show.head = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
    const showForm = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
        showForm.get = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:50
 * @route '/{current_team}/attachments/{attachment}'
 */
        showForm.head = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:60
 * @route '/{current_team}/attachments/{attachment}'
 */
export const destroy = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:60
 * @route '/{current_team}/attachments/{attachment}'
 */
destroy.url = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:60
 * @route '/{current_team}/attachments/{attachment}'
 */
destroy.delete = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:60
 * @route '/{current_team}/attachments/{attachment}'
 */
    const destroyForm = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:60
 * @route '/{current_team}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { current_team: string | number, attachment: number | { id: number } } | [current_team: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AttachmentController = { store, show, destroy }

export default AttachmentController