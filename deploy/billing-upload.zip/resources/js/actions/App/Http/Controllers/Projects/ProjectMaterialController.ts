import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::store
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:19
 * @route '/{current_team}/projects/{project}/materials'
 */
export const store = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/projects/{project}/materials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::store
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:19
 * @route '/{current_team}/projects/{project}/materials'
 */
store.url = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    project: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::store
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:19
 * @route '/{current_team}/projects/{project}/materials'
 */
store.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::store
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:19
 * @route '/{current_team}/projects/{project}/materials'
 */
    const storeForm = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::store
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:19
 * @route '/{current_team}/projects/{project}/materials'
 */
        storeForm.post = (args: { current_team: string | number, project: number | { id: number } } | [current_team: string | number, project: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::update
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:32
 * @route '/{current_team}/materials/{material}'
 */
export const update = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/materials/{material}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::update
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:32
 * @route '/{current_team}/materials/{material}'
 */
update.url = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    material: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                material: typeof args.material === 'object'
                ? args.material.id
                : args.material,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::update
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:32
 * @route '/{current_team}/materials/{material}'
 */
update.put = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::update
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:32
 * @route '/{current_team}/materials/{material}'
 */
    const updateForm = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::update
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:32
 * @route '/{current_team}/materials/{material}'
 */
        updateForm.put = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::destroy
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:44
 * @route '/{current_team}/materials/{material}'
 */
export const destroy = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/materials/{material}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::destroy
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:44
 * @route '/{current_team}/materials/{material}'
 */
destroy.url = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    material: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                material: typeof args.material === 'object'
                ? args.material.id
                : args.material,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::destroy
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:44
 * @route '/{current_team}/materials/{material}'
 */
destroy.delete = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::destroy
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:44
 * @route '/{current_team}/materials/{material}'
 */
    const destroyForm = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Projects\ProjectMaterialController::destroy
 * @see app/Http/Controllers/Projects/ProjectMaterialController.php:44
 * @route '/{current_team}/materials/{material}'
 */
        destroyForm.delete = (args: { current_team: string | number, material: number | { id: number } } | [current_team: string | number, material: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ProjectMaterialController = { store, update, destroy }

export default ProjectMaterialController