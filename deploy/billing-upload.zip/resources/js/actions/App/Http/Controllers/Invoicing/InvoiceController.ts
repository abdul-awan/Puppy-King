import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
export const exportMethod = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
exportMethod.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return exportMethod.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
exportMethod.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
exportMethod.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
    const exportMethodForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
        exportMethodForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::exportMethod
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:390
 * @route '/{current_team}/invoices/export'
 */
        exportMethodForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
export const pdf = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices/{invoice}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
pdf.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
pdf.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
pdf.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::pdf
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:241
 * @route '/{current_team}/invoices/{invoice}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::issue
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:229
 * @route '/{current_team}/invoices/{invoice}/issue'
 */
export const issue = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

issue.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/issue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::issue
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:229
 * @route '/{current_team}/invoices/{invoice}/issue'
 */
issue.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return issue.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::issue
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:229
 * @route '/{current_team}/invoices/{invoice}/issue'
 */
issue.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::issue
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:229
 * @route '/{current_team}/invoices/{invoice}/issue'
 */
    const issueForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: issue.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::issue
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:229
 * @route '/{current_team}/invoices/{invoice}/issue'
 */
        issueForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: issue.url(args, options),
            method: 'post',
        })
    
    issue.form = issueForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::send
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:254
 * @route '/{current_team}/invoices/{invoice}/send'
 */
export const send = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::send
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:254
 * @route '/{current_team}/invoices/{invoice}/send'
 */
send.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return send.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::send
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:254
 * @route '/{current_team}/invoices/{invoice}/send'
 */
send.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::send
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:254
 * @route '/{current_team}/invoices/{invoice}/send'
 */
    const sendForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::send
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:254
 * @route '/{current_team}/invoices/{invoice}/send'
 */
        sendForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(args, options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::markSent
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:275
 * @route '/{current_team}/invoices/{invoice}/mark-sent'
 */
export const markSent = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSent.url(args, options),
    method: 'post',
})

markSent.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/mark-sent',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::markSent
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:275
 * @route '/{current_team}/invoices/{invoice}/mark-sent'
 */
markSent.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return markSent.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::markSent
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:275
 * @route '/{current_team}/invoices/{invoice}/mark-sent'
 */
markSent.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSent.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::markSent
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:275
 * @route '/{current_team}/invoices/{invoice}/mark-sent'
 */
    const markSentForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markSent.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::markSent
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:275
 * @route '/{current_team}/invoices/{invoice}/mark-sent'
 */
        markSentForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markSent.url(args, options),
            method: 'post',
        })
    
    markSent.form = markSentForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::remind
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:288
 * @route '/{current_team}/invoices/{invoice}/remind'
 */
export const remind = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remind.url(args, options),
    method: 'post',
})

remind.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/remind',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::remind
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:288
 * @route '/{current_team}/invoices/{invoice}/remind'
 */
remind.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return remind.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::remind
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:288
 * @route '/{current_team}/invoices/{invoice}/remind'
 */
remind.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remind.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::remind
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:288
 * @route '/{current_team}/invoices/{invoice}/remind'
 */
    const remindForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remind.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::remind
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:288
 * @route '/{current_team}/invoices/{invoice}/remind'
 */
        remindForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remind.url(args, options),
            method: 'post',
        })
    
    remind.form = remindForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::fbrNumber
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:308
 * @route '/{current_team}/invoices/{invoice}/fbr-number'
 */
export const fbrNumber = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: fbrNumber.url(args, options),
    method: 'patch',
})

fbrNumber.definition = {
    methods: ["patch"],
    url: '/{current_team}/invoices/{invoice}/fbr-number',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::fbrNumber
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:308
 * @route '/{current_team}/invoices/{invoice}/fbr-number'
 */
fbrNumber.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return fbrNumber.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::fbrNumber
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:308
 * @route '/{current_team}/invoices/{invoice}/fbr-number'
 */
fbrNumber.patch = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: fbrNumber.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::fbrNumber
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:308
 * @route '/{current_team}/invoices/{invoice}/fbr-number'
 */
    const fbrNumberForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: fbrNumber.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::fbrNumber
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:308
 * @route '/{current_team}/invoices/{invoice}/fbr-number'
 */
        fbrNumberForm.patch = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: fbrNumber.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    fbrNumber.form = fbrNumberForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::duplicate
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:322
 * @route '/{current_team}/invoices/{invoice}/duplicate'
 */
export const duplicate = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

duplicate.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/duplicate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::duplicate
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:322
 * @route '/{current_team}/invoices/{invoice}/duplicate'
 */
duplicate.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return duplicate.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::duplicate
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:322
 * @route '/{current_team}/invoices/{invoice}/duplicate'
 */
duplicate.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::duplicate
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:322
 * @route '/{current_team}/invoices/{invoice}/duplicate'
 */
    const duplicateForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: duplicate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::duplicate
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:322
 * @route '/{current_team}/invoices/{invoice}/duplicate'
 */
        duplicateForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: duplicate.url(args, options),
            method: 'post',
        })
    
    duplicate.form = duplicateForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::credit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:350
 * @route '/{current_team}/invoices/{invoice}/credit'
 */
export const credit = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: credit.url(args, options),
    method: 'post',
})

credit.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices/{invoice}/credit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::credit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:350
 * @route '/{current_team}/invoices/{invoice}/credit'
 */
credit.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return credit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::credit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:350
 * @route '/{current_team}/invoices/{invoice}/credit'
 */
credit.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: credit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::credit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:350
 * @route '/{current_team}/invoices/{invoice}/credit'
 */
    const creditForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: credit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::credit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:350
 * @route '/{current_team}/invoices/{invoice}/credit'
 */
        creditForm.post = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: credit.url(args, options),
            method: 'post',
        })
    
    credit.form = creditForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::index
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:52
 * @route '/{current_team}/invoices'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::create
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:89
 * @route '/{current_team}/invoices/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::store
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:122
 * @route '/{current_team}/invoices'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/invoices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::store
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:122
 * @route '/{current_team}/invoices'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::store
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:122
 * @route '/{current_team}/invoices'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::store
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:122
 * @route '/{current_team}/invoices'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::store
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:122
 * @route '/{current_team}/invoices'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
export const show = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
show.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
show.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
show.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
    const showForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
        showForm.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::show
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:152
 * @route '/{current_team}/invoices/{invoice}'
 */
        showForm.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
export const edit = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/invoices/{invoice}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
edit.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
edit.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
edit.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
    const editForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
        editForm.get = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::edit
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:173
 * @route '/{current_team}/invoices/{invoice}/edit'
 */
        editForm.head = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
export const update = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/invoices/{invoice}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
update.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
update.put = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
update.patch = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
    const updateForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
        updateForm.put = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::update
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:188
 * @route '/{current_team}/invoices/{invoice}'
 */
        updateForm.patch = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:213
 * @route '/{current_team}/invoices/{invoice}'
 */
export const destroy = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/invoices/{invoice}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:213
 * @route '/{current_team}/invoices/{invoice}'
 */
destroy.url = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\InvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:213
 * @route '/{current_team}/invoices/{invoice}'
 */
destroy.delete = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:213
 * @route '/{current_team}/invoices/{invoice}'
 */
    const destroyForm = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\InvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/InvoiceController.php:213
 * @route '/{current_team}/invoices/{invoice}'
 */
        destroyForm.delete = (args: { current_team: string | number, invoice: number | { id: number } } | [current_team: string | number, invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const InvoiceController = { exportMethod, pdf, issue, send, markSent, remind, fbrNumber, duplicate, credit, index, create, store, show, edit, update, destroy, export: exportMethod }

export default InvoiceController