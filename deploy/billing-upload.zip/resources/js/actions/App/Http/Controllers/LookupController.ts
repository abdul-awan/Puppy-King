import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
const LookupController = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: LookupController.url(args, options),
    method: 'get',
})

LookupController.definition = {
    methods: ["get","head"],
    url: '/{current_team}/lookup/{type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
LookupController.url = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                type: args.type,
                }

    return LookupController.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
LookupController.get = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: LookupController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
LookupController.head = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: LookupController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
    const LookupControllerForm = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: LookupController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
        LookupControllerForm.get = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: LookupController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LookupController::__invoke
 * @see app/Http/Controllers/LookupController.php:25
 * @route '/{current_team}/lookup/{type}'
 */
        LookupControllerForm.head = (args: { current_team: string | number, type: string | number } | [current_team: string | number, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: LookupController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    LookupController.form = LookupControllerForm
export default LookupController