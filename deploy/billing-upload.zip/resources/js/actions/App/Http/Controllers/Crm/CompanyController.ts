import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Crm\CompanyController::archive
 * @see app/Http/Controllers/Crm/CompanyController.php:148
 * @route '/{current_team}/companies/{company}/archive'
 */
export const archive = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

archive.definition = {
    methods: ["patch"],
    url: '/{current_team}/companies/{company}/archive',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::archive
 * @see app/Http/Controllers/Crm/CompanyController.php:148
 * @route '/{current_team}/companies/{company}/archive'
 */
archive.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return archive.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::archive
 * @see app/Http/Controllers/Crm/CompanyController.php:148
 * @route '/{current_team}/companies/{company}/archive'
 */
archive.patch = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::archive
 * @see app/Http/Controllers/Crm/CompanyController.php:148
 * @route '/{current_team}/companies/{company}/archive'
 */
    const archiveForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::archive
 * @see app/Http/Controllers/Crm/CompanyController.php:148
 * @route '/{current_team}/companies/{company}/archive'
 */
        archiveForm.patch = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CompanyController::index
 * @see app/Http/Controllers/Crm/CompanyController.php:29
 * @route '/{current_team}/companies'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/companies/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CompanyController::create
 * @see app/Http/Controllers/Crm/CompanyController.php:69
 * @route '/{current_team}/companies/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::store
 * @see app/Http/Controllers/Crm/CompanyController.php:77
 * @route '/{current_team}/companies'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/companies',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::store
 * @see app/Http/Controllers/Crm/CompanyController.php:77
 * @route '/{current_team}/companies'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::store
 * @see app/Http/Controllers/Crm/CompanyController.php:77
 * @route '/{current_team}/companies'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::store
 * @see app/Http/Controllers/Crm/CompanyController.php:77
 * @route '/{current_team}/companies'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::store
 * @see app/Http/Controllers/Crm/CompanyController.php:77
 * @route '/{current_team}/companies'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
export const show = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/companies/{company}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
show.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
show.get = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
show.head = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
    const showForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
        showForm.get = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CompanyController::show
 * @see app/Http/Controllers/Crm/CompanyController.php:96
 * @route '/{current_team}/companies/{company}'
 */
        showForm.head = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
export const edit = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/companies/{company}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
edit.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
edit.get = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
edit.head = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
    const editForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
        editForm.get = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Crm\CompanyController::edit
 * @see app/Http/Controllers/Crm/CompanyController.php:118
 * @route '/{current_team}/companies/{company}/edit'
 */
        editForm.head = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
export const update = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/companies/{company}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
update.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
update.put = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
update.patch = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
    const updateForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
        updateForm.put = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Crm\CompanyController::update
 * @see app/Http/Controllers/Crm/CompanyController.php:131
 * @route '/{current_team}/companies/{company}'
 */
        updateForm.patch = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Crm\CompanyController::destroy
 * @see app/Http/Controllers/Crm/CompanyController.php:162
 * @route '/{current_team}/companies/{company}'
 */
export const destroy = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/companies/{company}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Crm\CompanyController::destroy
 * @see app/Http/Controllers/Crm/CompanyController.php:162
 * @route '/{current_team}/companies/{company}'
 */
destroy.url = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    company: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Crm\CompanyController::destroy
 * @see app/Http/Controllers/Crm/CompanyController.php:162
 * @route '/{current_team}/companies/{company}'
 */
destroy.delete = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Crm\CompanyController::destroy
 * @see app/Http/Controllers/Crm/CompanyController.php:162
 * @route '/{current_team}/companies/{company}'
 */
    const destroyForm = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Crm\CompanyController::destroy
 * @see app/Http/Controllers/Crm/CompanyController.php:162
 * @route '/{current_team}/companies/{company}'
 */
        destroyForm.delete = (args: { current_team: string | number, company: number | { id: number } } | [current_team: string | number, company: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CompanyController = { archive, index, create, store, show, edit, update, destroy }

export default CompanyController