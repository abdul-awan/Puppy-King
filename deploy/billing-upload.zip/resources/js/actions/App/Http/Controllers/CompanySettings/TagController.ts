import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/tags',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\TagController::index
 * @see app/Http/Controllers/CompanySettings/TagController.php:19
 * @route '/{current_team}/settings/tags'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\TagController::store
 * @see app/Http/Controllers/CompanySettings/TagController.php:39
 * @route '/{current_team}/settings/tags'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/tags',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\TagController::store
 * @see app/Http/Controllers/CompanySettings/TagController.php:39
 * @route '/{current_team}/settings/tags'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TagController::store
 * @see app/Http/Controllers/CompanySettings/TagController.php:39
 * @route '/{current_team}/settings/tags'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TagController::store
 * @see app/Http/Controllers/CompanySettings/TagController.php:39
 * @route '/{current_team}/settings/tags'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TagController::store
 * @see app/Http/Controllers/CompanySettings/TagController.php:39
 * @route '/{current_team}/settings/tags'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
export const update = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/tags/{tag}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
update.url = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    tag: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                tag: typeof args.tag === 'object'
                ? args.tag.id
                : args.tag,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{tag}', parsedArgs.tag.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
update.put = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
update.patch = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
    const updateForm = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
        updateForm.put = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\TagController::update
 * @see app/Http/Controllers/CompanySettings/TagController.php:51
 * @route '/{current_team}/settings/tags/{tag}'
 */
        updateForm.patch = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\TagController::destroy
 * @see app/Http/Controllers/CompanySettings/TagController.php:63
 * @route '/{current_team}/settings/tags/{tag}'
 */
export const destroy = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/tags/{tag}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\TagController::destroy
 * @see app/Http/Controllers/CompanySettings/TagController.php:63
 * @route '/{current_team}/settings/tags/{tag}'
 */
destroy.url = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    tag: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                tag: typeof args.tag === 'object'
                ? args.tag.id
                : args.tag,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{tag}', parsedArgs.tag.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\TagController::destroy
 * @see app/Http/Controllers/CompanySettings/TagController.php:63
 * @route '/{current_team}/settings/tags/{tag}'
 */
destroy.delete = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\TagController::destroy
 * @see app/Http/Controllers/CompanySettings/TagController.php:63
 * @route '/{current_team}/settings/tags/{tag}'
 */
    const destroyForm = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\TagController::destroy
 * @see app/Http/Controllers/CompanySettings/TagController.php:63
 * @route '/{current_team}/settings/tags/{tag}'
 */
        destroyForm.delete = (args: { current_team: string | number, tag: number | { id: number } } | [current_team: string | number, tag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TagController = { index, store, update, destroy }

export default TagController