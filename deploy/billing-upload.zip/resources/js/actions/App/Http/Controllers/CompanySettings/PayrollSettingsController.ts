import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
export const edit = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
edit.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
edit.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
edit.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
    const editForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
        editForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::edit
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:31
 * @route '/{current_team}/settings/payroll'
 */
        editForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::update
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:81
 * @route '/{current_team}/settings/payroll'
 */
export const update = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/payroll',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::update
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:81
 * @route '/{current_team}/settings/payroll'
 */
update.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::update
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:81
 * @route '/{current_team}/settings/payroll'
 */
update.put = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::update
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:81
 * @route '/{current_team}/settings/payroll'
 */
    const updateForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\PayrollSettingsController::update
 * @see app/Http/Controllers/CompanySettings/PayrollSettingsController.php:81
 * @route '/{current_team}/settings/payroll'
 */
        updateForm.put = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const PayrollSettingsController = { edit, update }

export default PayrollSettingsController