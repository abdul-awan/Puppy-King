import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
export const pdf = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/{current_team}/credit-notes/{credit_note}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
pdf.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return pdf.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
pdf.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
pdf.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
    const pdfForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
        pdfForm.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::pdf
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:142
 * @route '/{current_team}/credit-notes/{credit_note}/pdf'
 */
        pdfForm.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pdf.form = pdfForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::issue
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:130
 * @route '/{current_team}/credit-notes/{credit_note}/issue'
 */
export const issue = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

issue.definition = {
    methods: ["post"],
    url: '/{current_team}/credit-notes/{credit_note}/issue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::issue
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:130
 * @route '/{current_team}/credit-notes/{credit_note}/issue'
 */
issue.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return issue.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::issue
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:130
 * @route '/{current_team}/credit-notes/{credit_note}/issue'
 */
issue.post = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::issue
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:130
 * @route '/{current_team}/credit-notes/{credit_note}/issue'
 */
    const issueForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: issue.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::issue
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:130
 * @route '/{current_team}/credit-notes/{credit_note}/issue'
 */
        issueForm.post = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: issue.url(args, options),
            method: 'post',
        })
    
    issue.form = issueForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::send
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:155
 * @route '/{current_team}/credit-notes/{credit_note}/send'
 */
export const send = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/{current_team}/credit-notes/{credit_note}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::send
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:155
 * @route '/{current_team}/credit-notes/{credit_note}/send'
 */
send.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return send.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::send
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:155
 * @route '/{current_team}/credit-notes/{credit_note}/send'
 */
send.post = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::send
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:155
 * @route '/{current_team}/credit-notes/{credit_note}/send'
 */
    const sendForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::send
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:155
 * @route '/{current_team}/credit-notes/{credit_note}/send'
 */
        sendForm.post = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(args, options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/credit-notes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::index
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:33
 * @route '/{current_team}/credit-notes'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
export const show = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/credit-notes/{credit_note}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
show.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
show.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
show.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
    const showForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
        showForm.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::show
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:58
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
        showForm.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
export const edit = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/credit-notes/{credit_note}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
edit.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
edit.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
edit.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
    const editForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
        editForm.get = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::edit
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:73
 * @route '/{current_team}/credit-notes/{credit_note}/edit'
 */
        editForm.head = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
export const update = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/credit-notes/{credit_note}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
update.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
update.put = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
update.patch = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
    const updateForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
        updateForm.put = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::update
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:88
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
        updateForm.patch = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::destroy
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:115
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
export const destroy = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/credit-notes/{credit_note}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::destroy
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:115
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
destroy.url = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    credit_note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                credit_note: typeof args.credit_note === 'object'
                ? args.credit_note.id
                : args.credit_note,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{credit_note}', parsedArgs.credit_note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::destroy
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:115
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
destroy.delete = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::destroy
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:115
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
    const destroyForm = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\CreditNoteController::destroy
 * @see app/Http/Controllers/Invoicing/CreditNoteController.php:115
 * @route '/{current_team}/credit-notes/{credit_note}'
 */
        destroyForm.delete = (args: { current_team: string | number, credit_note: number | { id: number } } | [current_team: string | number, credit_note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CreditNoteController = { pdf, issue, send, index, show, edit, update, destroy }

export default CreditNoteController