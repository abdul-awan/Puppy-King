import DashboardController from './DashboardController'
import CompanyController from './CompanyController'
import UserController from './UserController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
CompanyController: Object.assign(CompanyController, CompanyController),
UserController: Object.assign(UserController, UserController),
}

export default Admin