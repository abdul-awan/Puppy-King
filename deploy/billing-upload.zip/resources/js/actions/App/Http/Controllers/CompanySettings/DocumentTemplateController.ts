import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::preview
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:157
 * @route '/{current_team}/settings/invoice-settings/templates/preview'
 */
export const preview = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

preview.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/invoice-settings/templates/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::preview
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:157
 * @route '/{current_team}/settings/invoice-settings/templates/preview'
 */
preview.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return preview.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::preview
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:157
 * @route '/{current_team}/settings/invoice-settings/templates/preview'
 */
preview.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::preview
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:157
 * @route '/{current_team}/settings/invoice-settings/templates/preview'
 */
    const previewForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: preview.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::preview
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:157
 * @route '/{current_team}/settings/invoice-settings/templates/preview'
 */
        previewForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: preview.url(args, options),
            method: 'post',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/invoice-settings/templates/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::create
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:44
 * @route '/{current_team}/settings/invoice-settings/templates/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::store
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:63
 * @route '/{current_team}/settings/invoice-settings/templates'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/settings/invoice-settings/templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::store
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:63
 * @route '/{current_team}/settings/invoice-settings/templates'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::store
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:63
 * @route '/{current_team}/settings/invoice-settings/templates'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::store
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:63
 * @route '/{current_team}/settings/invoice-settings/templates'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::store
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:63
 * @route '/{current_team}/settings/invoice-settings/templates'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
export const edit = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
edit.url = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    documentTemplate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                documentTemplate: typeof args.documentTemplate === 'object'
                ? args.documentTemplate.id
                : args.documentTemplate,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{documentTemplate}', parsedArgs.documentTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
edit.get = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
edit.head = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
    const editForm = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
        editForm.get = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::edit
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:90
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}/edit'
 */
        editForm.head = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
export const update = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/settings/invoice-settings/templates/{documentTemplate}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
update.url = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    documentTemplate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                documentTemplate: typeof args.documentTemplate === 'object'
                ? args.documentTemplate.id
                : args.documentTemplate,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{documentTemplate}', parsedArgs.documentTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
update.put = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
update.patch = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
    const updateForm = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
        updateForm.put = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::update
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:105
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
        updateForm.patch = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::destroy
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:129
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
export const destroy = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/settings/invoice-settings/templates/{documentTemplate}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::destroy
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:129
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
destroy.url = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    documentTemplate: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                documentTemplate: typeof args.documentTemplate === 'object'
                ? args.documentTemplate.id
                : args.documentTemplate,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{documentTemplate}', parsedArgs.documentTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::destroy
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:129
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
destroy.delete = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::destroy
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:129
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
    const destroyForm = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\DocumentTemplateController::destroy
 * @see app/Http/Controllers/CompanySettings/DocumentTemplateController.php:129
 * @route '/{current_team}/settings/invoice-settings/templates/{documentTemplate}'
 */
        destroyForm.delete = (args: { current_team: string | number, documentTemplate: number | { id: number } } | [current_team: string | number, documentTemplate: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DocumentTemplateController = { preview, create, store, edit, update, destroy }

export default DocumentTemplateController