import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/settings/members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::index
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:26
 * @route '/{current_team}/settings/members'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::update
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:57
 * @route '/{current_team}/settings/members/{user}'
 */
export const update = (args: { current_team: string | number, user: number | { id: number } } | [current_team: string | number, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/{current_team}/settings/members/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::update
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:57
 * @route '/{current_team}/settings/members/{user}'
 */
update.url = (args: { current_team: string | number, user: number | { id: number } } | [current_team: string | number, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::update
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:57
 * @route '/{current_team}/settings/members/{user}'
 */
update.put = (args: { current_team: string | number, user: number | { id: number } } | [current_team: string | number, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::update
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:57
 * @route '/{current_team}/settings/members/{user}'
 */
    const updateForm = (args: { current_team: string | number, user: number | { id: number } } | [current_team: string | number, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettings\MemberAccessController::update
 * @see app/Http/Controllers/CompanySettings/MemberAccessController.php:57
 * @route '/{current_team}/settings/members/{user}'
 */
        updateForm.put = (args: { current_team: string | number, user: number | { id: number } } | [current_team: string | number, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const MemberAccessController = { index, update }

export default MemberAccessController