import CalendarController from './CalendarController'
const Calendar = {
    CalendarController: Object.assign(CalendarController, CalendarController),
}

export default Calendar