import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::generate
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:185
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/generate'
 */
export const generate = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::generate
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:185
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/generate'
 */
generate.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return generate.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::generate
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:185
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/generate'
 */
generate.post = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::generate
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:185
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/generate'
 */
    const generateForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::generate
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:185
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/generate'
 */
        generateForm.post = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(args, options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::toggle
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:199
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/toggle'
 */
export const toggle = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::toggle
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:199
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/toggle'
 */
toggle.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return toggle.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::toggle
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:199
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/toggle'
 */
toggle.post = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::toggle
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:199
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/toggle'
 */
    const toggleForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::toggle
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:199
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/toggle'
 */
        toggleForm.post = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, options),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
export const index = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/{current_team}/recurring-invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
index.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return index.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
index.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
index.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
    const indexForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
        indexForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::index
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:41
 * @route '/{current_team}/recurring-invoices'
 */
        indexForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
export const create = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/{current_team}/recurring-invoices/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
create.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return create.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
create.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
create.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
    const createForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
        createForm.get = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::create
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:78
 * @route '/{current_team}/recurring-invoices/create'
 */
        createForm.head = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::store
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:99
 * @route '/{current_team}/recurring-invoices'
 */
export const store = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/{current_team}/recurring-invoices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::store
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:99
 * @route '/{current_team}/recurring-invoices'
 */
store.url = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { current_team: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                }

    return store.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::store
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:99
 * @route '/{current_team}/recurring-invoices'
 */
store.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::store
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:99
 * @route '/{current_team}/recurring-invoices'
 */
    const storeForm = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::store
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:99
 * @route '/{current_team}/recurring-invoices'
 */
        storeForm.post = (args: { current_team: string | number } | [current_team: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
export const show = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
show.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return show.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
show.get = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
show.head = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
    const showForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
        showForm.get = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::show
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:124
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
        showForm.head = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
export const edit = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
edit.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return edit.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
edit.get = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
edit.head = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
    const editForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
        editForm.get = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::edit
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:141
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}/edit'
 */
        editForm.head = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
export const update = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
update.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return update.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
update.put = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
update.patch = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
    const updateForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
        updateForm.put = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::update
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:154
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
        updateForm.patch = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:173
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
export const destroy = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/{current_team}/recurring-invoices/{recurring_invoice}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:173
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
destroy.url = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    current_team: args[0],
                    recurring_invoice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        current_team: args.current_team,
                                recurring_invoice: typeof args.recurring_invoice === 'object'
                ? args.recurring_invoice.id
                : args.recurring_invoice,
                }

    return destroy.definition.url
            .replace('{current_team}', parsedArgs.current_team.toString())
            .replace('{recurring_invoice}', parsedArgs.recurring_invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:173
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
destroy.delete = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:173
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
    const destroyForm = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Invoicing\RecurringInvoiceController::destroy
 * @see app/Http/Controllers/Invoicing/RecurringInvoiceController.php:173
 * @route '/{current_team}/recurring-invoices/{recurring_invoice}'
 */
        destroyForm.delete = (args: { current_team: string | number, recurring_invoice: number | { id: number } } | [current_team: string | number, recurring_invoice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RecurringInvoiceController = { generate, toggle, index, create, store, show, edit, update, destroy }

export default RecurringInvoiceController