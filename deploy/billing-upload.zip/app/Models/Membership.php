<?php

namespace App\Models;

use App\Enums\AccessLevel;
use App\Enums\Module;
use App\Enums\TeamRole;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\Pivot;
use Illuminate\Support\Carbon;

/**
 * @property int $id
 * @property int $team_id
 * @property int $user_id
 * @property TeamRole $role
 * @property array<string, string>|null $permissions
 * @property string|null $hourly_rate
 * @property int $daily_capacity_minutes
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read Team $team
 * @property-read User $user
 */
#[Fillable(['team_id', 'user_id', 'role', 'permissions', 'hourly_rate', 'daily_capacity_minutes'])]
class Membership extends Pivot
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'team_members';

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = true;

    /**
     * Get the team that the membership belongs to.
     *
     * @return BelongsTo<Team, $this>
     */
    public function team(): BelongsTo
    {
        return $this->belongsTo(Team::class);
    }

    /**
     * Get the user that belongs to this membership.
     *
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the member's access level for a module. Owners and admins have full access.
     */
    public function access(Module $module): AccessLevel
    {
        if ($this->role->isAtLeast(TeamRole::Admin)) {
            return AccessLevel::Write;
        }

        $value = $this->permissions[$module->value] ?? null;

        return (is_string($value) ? AccessLevel::tryFrom($value) : null) ?? $module->defaultMemberAccess();
    }

    /**
     * Get the member's access level for every module.
     *
     * @return array<string, string>
     */
    public function accessMap(): array
    {
        $map = [];

        foreach (Module::cases() as $module) {
            $map[$module->value] = $this->access($module)->value;
        }

        return $map;
    }

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'role' => TeamRole::class,
            'permissions' => 'array',
            'hourly_rate' => 'decimal:2',
            'daily_capacity_minutes' => 'integer',
        ];
    }
}
